from enum import Enum
from datetime import datetime
from xml.etree import ElementTree


def format_datetime(date_time:datetime) -> datetime:
    return datetime(date_time.year, date_time.month, date_time.day, date_time.hour, date_time.minute, 0)


def format_datetime_str(date_time:datetime) -> str:
    return "{:04d}-{:02d}-{:02d} {:02d}:{:02d}".format(date_time.year, date_time.month, date_time.day,
                                                       date_time.hour, date_time.minute)


def format_spend_str(spend: int) -> str:
    return "{:02d}日-{:02d}时-{:02d}分".format(spend // (24 * 60), (spend // 60) % 24, spend % 24)


class TaskState(Enum):
    NotStarted = 0  # 未开始
    Processing = 1  # 进行中
    Finished = 2  # 完成
    OutOfDate = 3  # 过期

    Recycled = 4  # 回收站

    def trans(self):
        if self == TaskState.NotStarted:
            return "未开始"
        elif self == TaskState.Processing:
            return "进行中"
        elif self == TaskState.Finished:
            return "已完成"
        else:
            return "已回收"


TaskKind = {'Sport': 1,
            'Study': 2,
            'Work': 3,
            'Entertainment': 4,
            'Rest': 5,
            'Commute': 6,
            'Exam': 7,
            'Remedy': 8,
            'Triviality': 9}

TaskKindRe = {1: 'Sport',
              2: 'Study',
              3: 'Work',
              4: 'Entertainment',
              5: 'Rest',
              6: 'Commute',
              7: 'Exam',
              8: 'Remedy',
              9: 'Triviality'}


# 属性清单
# task_id       任务id标识符
# name          任务名称
# description   任务描述
# kind          任务类别
# startDate     任务开始时间
# endDate       任务结束时间
# spend         任务消耗时间，单位为分钟
# importance    重要性
# isLeisure     是否为空闲，空闲任务为最高优先级 10

# taskState     任务当前状态
class Task:
    def __init__(self, task_id: str, name: str, description: str, kind: str, start_date: datetime,
                 end_date: datetime, cur_date: datetime, spend: int, importance: int, rest: int,
                 is_repeat: bool = False, repeat_day = None, final_date: datetime = datetime(9999, 12, 31, 0, 0),
                 is_leisure: bool = False, task_state: TaskState or None = None, finish_date: datetime or None = None):
        if repeat_day is None:
            repeat_day = [False, False, False, False, False, False, False]
        self.task_id = task_id
        self.name = name
        self.description = description
        self.kind = kind
        self.startDate = start_date
        self.endDate = end_date
        self.spend = spend

        self.isLeisure = is_leisure
        self.isRepeat = is_repeat
        self.finalDate = final_date
        if repeat_day is None:
            self.repeatDay = [False, False, False, False, False, False, False]
        else:
            self.repeatDay = repeat_day
        if is_leisure:
            self.importance = 10
        else:
            self.importance = importance
        self.rest = rest
        if task_state is None:
            self.taskState = TaskState.NotStarted
            self.check_state(cur_date)
        else:
            self.taskState = task_state
        if finish_date is None:
            self.finishDate: datetime = cur_date
        else:
            self.finishDate = finish_date

    def check_state(self, cur_date: datetime) -> TaskState:
        """
        根据当前时间，检查任务状态，若任务已经过期或完成则跳过
        :param cur_date: 当前时间
        :return:
        """
        if self.taskState == TaskState.NotStarted or self.taskState == TaskState.Processing:
            if cur_date < self.startDate:
                self.taskState = TaskState.NotStarted
            elif self.startDate <= cur_date <= self.endDate:
                self.taskState = TaskState.Processing
            else:
                self.taskState = TaskState.OutOfDate
        return self.taskState

    def reset_state(self, cur_date: datetime) -> TaskState:
        """
        若任务未完成，则重置任务状态，用于更新起始时间或终止时间后调用
        :param cur_date: 当前时间
        :return:
        """
        if self.taskState != TaskState.Finished:
            if cur_date < self.startDate:
                self.taskState = TaskState.NotStarted
            elif self.startDate <= cur_date <= self.endDate:
                self.taskState = TaskState.Processing
            else:
                self.taskState = TaskState.OutOfDate
        return self.taskState

    def finish(self, cur_date: datetime) -> TaskState:
        """
        完成任务，注意，若任务已过期或超出时间，则不应调用该方法
        :param cur_date:
        :return:
        """
        if cur_date <= self.endDate:
            self.taskState = TaskState.Finished
            self.finishDate = cur_date
        return self.taskState

    def set_description(self, description: str) -> None:
        """
        修改描述
        :param description:
        :return:
        """
        self.description = description

    def set_start_date(self, start_date: datetime, cur_date: datetime) -> None:
        """
        修改开始时间
        :param start_date:
        :param cur_date:
        :return:
        """
        self.startDate = start_date
        self.reset_state(cur_date)

    def set_end_date(self, end_state: datetime, cur_date: datetime) -> TaskState:
        """
        修改终止时间
        :param end_state:
        :param cur_date:
        :return:
        """
        self.endDate = end_state
        return self.reset_state(cur_date)

    def set_importance(self, importance: int) -> None:
        """
        修改任务重要性，注意若任务为空闲时间特殊任务，则此方法无效
        :param importance:
        :return:
        """
        if not self.isLeisure:
            self.importance = importance

    def set_name(self, name: str) -> None:
        """
        修改任务名称
        :param name:
        :return:
        """
        self.name = name

    def set_spend(self, spend: int) -> bool:
        """
        修改任务需求时间
        :param spend:需求时间，单位为分
        :return:
        """
        if (self.endDate - self.startDate).total_seconds() * 60 < spend:
            return False
        else:
            self.spend = spend
            return True

    def get_start_date(self) -> datetime:
        return self.startDate

    def get_end_date(self) -> datetime:
        return self.endDate

    def save(self, parent_element: ElementTree.Element) -> None:
        def trans_repeat_day(day: list) ->int:
            result = 0
            base = 1
            for i in range(7):
                if day[i]:
                    result = result | base
                base = base << 1
            return result
        ElementTree.SubElement(parent_element, "task", attrib={'name': self.name,
                                                               'description': self.description,
                                                               'kind': str(self.kind),
                                                               'start_date': str(self.startDate),
                                                               'end_date': str(self.endDate),
                                                               'spend': str(self.spend),
                                                               'rest': str(self.rest),
                                                               'is_repeat': str(self.isRepeat),
                                                               'repeat_day':str(trans_repeat_day(self.repeatDay)),
                                                               'final_date':str(self.finalDate),
                                                               'isLeisure': str(self.isLeisure),
                                                               'importance': str(self.importance),
                                                               'task_state': str(self.taskState.value),
                                                               'finish_state': str(self.finishDate)})


def load(parent_element: ElementTree.Element) -> Task:
    def str_to_date_time(s: str) -> datetime:
        date, time = s.split(" ")
        year, day, month = map(int, date.split("-"))
        time_split = time.split(":")
        hour = int(time_split[0])
        minute = int(time_split[1])
        return datetime(year, day, month, hour, minute, 0)

    def load_repeat_day(s: str) -> list:
        day = int(s)
        base = 1
        result = []
        for i in range(7):
            if day & base == 1:
                result.append(True)
            else:
                result.append(False)
        return result

    task_id = parent_element.attrib['task_id']

    task_dict = parent_element[0].attrib
    name = task_dict['name']
    description = task_dict['description']
    kind = task_dict['kind']
    start_date = str_to_date_time(task_dict['start_date'])
    end_date = str_to_date_time(task_dict['end_date'])
    spend = int(task_dict['spend'])
    rest = int(task_dict['rest'])
    is_repeat = bool(task_dict['is_repeat'])
    repeat_day = load_repeat_day(task_dict['repeat_day'])
    final_date = str_to_date_time(task_dict['final_date'])
    is_leisure = bool(task_dict['isLeisure'])
    importance = int(task_dict['importance'])
    task_state = TaskState(int(task_dict['task_state']))
    finish_date = str_to_date_time(task_dict['finish_state'])

    return Task(task_id, name, description, kind, start_date, end_date, datetime.now(), spend,
                importance, rest, is_repeat, repeat_day, final_date, is_leisure, task_state, finish_date)
