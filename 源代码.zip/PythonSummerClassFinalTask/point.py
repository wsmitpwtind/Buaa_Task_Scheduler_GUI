from random import random
from PyQt5.QtCore import QPropertyAnimation, QObject, pyqtProperty, QEasingCurve,pyqtSignal
from PyQt5.QtGui import QColor
import math


class Point(QObject):
    valueChanged = pyqtSignal()

    def __init__(self, x, ox, y, oy, *args, **kwargs):
        super(Point, self).__init__(*args, **kwargs)
        self.__x = x
        self._x = x
        self.originX = ox
        self._y = y
        self.__y = y
        self.originY = oy
        self.preEndX = -1
        self.preEndY = -1
        # 5个闭合点
        self.closest = [0, 0, 0, 0, 0]
        # 圆半径
        self.radius = 2 + random() * 2
        # 连线颜色
        self.lineColor = QColor(156, 217, 249)
        # 圆颜色
        self.circleColor = QColor(156, 217, 249)

        self.xAnimation = None
        self.yAnimation = None

    def init_animation(self):
        # 属性动画
        if self.xAnimation is None or self.yAnimation is None:
            self.xAnimation = QPropertyAnimation(
               self, b'x', self, valueChanged=self.valueChanged.emit,
               easingCurve=QEasingCurve.InOutSine, finished=self.update_animation)
            self.yAnimation = QPropertyAnimation(
                self, b'y', self, valueChanged=self.valueChanged.emit,
                easingCurve=QEasingCurve.InOutSine,
                finished=self.update_animation)
            self.update_animation()

    def update_animation(self):
        self.xAnimation.stop()
        self.yAnimation.stop()
        duration = (1 + random()) * 1000
        self.xAnimation.setDuration(int(duration))
        self.yAnimation.setDuration(int(duration))
        if self.preEndX == -1:
            self.xAnimation.setStartValue(self.__x)
        else:
            self.xAnimation.setStartValue(self.preEndX)
        endX = self.originX - 50 + random() * 100
        self.xAnimation.setEndValue(endX)
        self.preEndX = endX
        if self.preEndY == -1:
            self.yAnimation.setStartValue(self.__y)
        else:
            self.yAnimation.setStartValue(self.preEndY)
        endY = self.originY - 50 + random() * 100
        self.yAnimation.setEndValue(endY)
        self.preEndY = endY
        self.xAnimation.start()
        self.yAnimation.start()

    @pyqtProperty(float)
    def x(self):
        return self._x

    @x.setter
    def x(self, x):
        self._x = x

    @pyqtProperty(float)
    def y(self):
        return self._y

    @y.setter
    def y(self, y):
        self._y = y


class Dual:
    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y


def get_dis(p1: Dual or Point, p2: Dual or Point):
    return math.pow(p1.x - p2.x, 2) + math.pow(p1.y - p2.y, 2)


def find_close(points):
    points_len = len(points)
    for i in range(points_len):
        closest = [None, None, None, None, None]
        p1 = points[i]
        for j in range(points_len):
            p2 = points[j]
            dte1 = get_dis(p1, p2)
            if p1 != p2:
                placed = False
                for k in range(5):
                    if not placed:
                        if not closest[k]:
                            closest[k] = p2
                            placed = True
                for k in range(5):
                    if not placed:
                        if dte1 < get_dis(p1, closest[k]):
                            closest[k] = p2
                            placed = True
        p1.closest = closest


"""class Point(QObject):
    valueChanged = pyqtSignal()

    def __init__(self, x, ox, y, oy, *args, **kwargs):
        super(Point, self).__init__(*args, **kwargs)
        self.__x = x
        self._x = x
        self.originX = ox
        self._y = y
        self.__y = y
        self.originY = oy
        self.preEndX = -1
        self.preEndY = -1
        # 5个闭合点
        self.closest = [0, 0, 0, 0, 0]
        # 圆半径
        self.radius = 2 + random() * 2
        # 连线颜色
        self.lineColor = QColor(156, 217, 249)
        # 圆颜色
        self.circleColor = QColor(156, 217, 249)

    def initAnimation(self):
        # 属性动画
        if not hasattr(self, 'xAnimation'):
            self.xAnimation = QPropertyAnimation(
                self, b'x', self, valueChanged=self.valueChanged.emit,
                easingCurve=QEasingCurve.InOutSine, finished=self.updateAnimation)
            self.yAnimation = QPropertyAnimation(
                self, b'y', self, valueChanged=self.valueChanged.emit,
                easingCurve=QEasingCurve.InOutSine,
                finished=self.updateAnimation)
            self.updateAnimation()

    def updateAnimation(self):
        self.xAnimation.stop()
        self.yAnimation.stop()
        duration = (1 + random()) * 1000
        self.xAnimation.setDuration(int(duration))
        self.yAnimation.setDuration(int(duration))
        if self.preEndX == -1:
            self.xAnimation.setStartValue(self.__x)
        else:
            self.xAnimation.setStartValue(self.preEndX)
        endX = self.originX - 50 + random() * 100
        self.xAnimation.setEndValue(endX)
        self.preEndX = endX
        if self.preEndY == -1:
            self.yAnimation.setStartValue(self.__y)
        else:
            self.yAnimation.setStartValue(self.preEndY)
        endY = self.originY - 50 + random() * 100
        self.yAnimation.setEndValue(endY)
        self.preEndY = endY
        self.xAnimation.start()
        self.yAnimation.start()

    @pyqtProperty(float)
    def x(self):
        return self._x

    @x.setter
    def x(self, x):
        self._x = x

    @pyqtProperty(float)
    def y(self):
        return self._y

    @y.setter
    def y(self, y):
        self._y = y"""
