from task import Task
from task import TaskState
from datetime import datetime


# 任务调度的返回结果，表示一种调度策略
# 属性清单
# tasks         被调度的任务
# time_table    被调度任务及其对应时刻表，周期性任务可能多次出现
class TaskTodoList:
    def __init__(self, tasks=None, time_table=None):
        if tasks is None:
            tasks = []
        if time_table is None:
            time_table = []
        self.tasks = tasks
        self.time_table = time_table

    def add_task(self, task: Task, begin_date: datetime, finish_date: datetime):
        if not self.tasks.__contains__(task):
            self.tasks.append(task)
        time_table_element = [task.task_id, task, begin_date, finish_date]
        self.time_table.append(time_table_element)
