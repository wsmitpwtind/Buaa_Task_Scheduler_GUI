暑期Python课大作业

# 文件架构介绍

## *.py

main.py: 入口文件

memo_window.py: 自定义窗口类

title_widget.py: 自定义顶部窗口类

ui_interface.py: ui_interface.ui生成文件

resource_rc.py: resource.qrc生成文件

## *.ui

ui_interface.ui: qtDesigner文件

## *.qrc

resource.qrc: 资源文件

## icons

图标

# 约定

1. 各自定义类、自定义函数添加注释
2. 函数限定传入参数类型和返回参数类型