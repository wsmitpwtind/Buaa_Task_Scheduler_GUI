from datetime import date, datetime, time

from PyQt5 import QtGui
from PyQt5.QtWidgets import QFrame, QLabel, QListWidget
from PyQt5 import QtCore
from PyQt5.QtCore import pyqtSignal, Qt, QModelIndex

from task import Task


class DayFrame(QFrame):
    """
    重写标题栏窗口，添加自定义信号
    """
    selected: pyqtSignal = pyqtSignal(int)  # 点击信号
    selectedItemChange: pyqtSignal = pyqtSignal([int, int])
    doubleItem: pyqtSignal = pyqtSignal([int, str])

    def __init__(self, parent=None):
        super(DayFrame, self).__init__(parent)
        self.index = -1
        self.isSelected = False
        self.label: QLabel = None
        self.listWidget: QListWidget = None
        self.tasks = []

    def create_map(self, index):
        self.index = index
        self.label: QLabel = self.findChildren(QLabel, options=Qt.FindDirectChildrenOnly)[0]
        self.listWidget: QListWidget = self.findChildren(QListWidget, options=Qt.FindDirectChildrenOnly)[0]
        self.listWidget.currentRowChanged.connect(self.selected_item_row_change)
        self.listWidget.doubleClicked.connect(self.double_selected_item)

    def set_date(self, cur_date:date):
        self.label.setText(str(cur_date.month) + "." + str(cur_date.day))
        self.listWidget.clear()
        self.tasks.clear()

    def add_task(self, begin_datetime: datetime, end_datetime: datetime, task: Task):
        self.tasks.append([begin_datetime, end_datetime, task])
        self.listWidget.addItem("{:02d}:{:02d}-{:02d}:{:02d}: {}".format(begin_datetime.hour, begin_datetime.minute,
                                                                         end_datetime.hour, end_datetime.minute,
                                                                         task.name))

    def get_tasks(self):
        return self.tasks

    def selected_item_row_change(self, current_row: int):
        if current_row != -1:
            self.selectedItemChange[int, int].emit(self.index, current_row)

    def set_selected_item_row(self, current_row:int):
        self.listWidget.setCurrentRow(current_row)

    def double_selected_item(self, current_row: QModelIndex):
        self.doubleItem[int, str].emit(self.index, self.tasks[current_row.row()][2].task_id)

    def initial_state(self) -> None:
        """
        初始状态
        :return:
        """
        self.setFrameShape(QFrame.WinPanel)
        self.setFrameShadow(QFrame.Raised)
        self.listWidget.setCurrentRow(-1)

    def via_state(self) -> None:
        """
        经过状态
        :return:
        """
        self.setFrameShape(QFrame.WinPanel)
        self.setFrameShadow(QFrame.Sunken)

    def selected_state(self) -> None:
        """
        选中状态
        :return:
        """
        self.setFrameShape(QFrame.WinPanel)
        self.setFrameShadow(QFrame.Sunken)

    def set_selected(self):
        self.isSelected = True
        self.selected_state()

    def set_not_selected(self):
        self.isSelected = False
        self.initial_state()

    def enterEvent(self, e: QtCore.QEvent) -> None:
        """
        鼠标进入时触发
        :param e:
        :return:
        """
        if not self.isSelected:
            self.via_state()
        e.accept()

    def leaveEvent(self, e: QtCore.QEvent) -> None:
        """
        鼠标移出时触发
        :param e:
        :return:
        """
        if not self.isSelected:
            self.initial_state()
        e.accept()

    def mousePressEvent(self, e: QtGui.QMouseEvent) -> None:
        """
        鼠标点击时触发，表示此QFrame被选中
        :param e:
        :return:
        """
        self.isSelected = True
        if self.index >= 0:
            self.selected[int].emit(self.index)
        self.selected_state()
        e.accept()