from PyQt5 import QtCore
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem, QHeaderView
from datetime import datetime, timedelta, date

from task import Task
from user import User


def format_task_time(task: Task):
    return "{:04d}-{:02d}-{:02d}--{:04d}-{:02d}-{:02d}".format(task.startDate.year, task.startDate.month,
                                                               task.startDate.day, task.endDate.year,
                                                               task.endDate.month, task.endDate.day)


def format_task_spend(task: Task):
    return "{:02d}d-{:02d}h-{:02d}m".format(task.spend // (24 * 60), (task.spend // 60) % 24, task.spend % 24)


def format_task_rest(task: Task):
    return "{:02d}d-{:02d}h-{:02d}m".format(task.rest // (24 * 60), (task.rest // 60) % 24, task.rest % 24)


def format_task_mnd(task: Task):
    return "{:02d}-{:02d}--{:02d}-{:02d}".format(task.startDate.hour,
                                                 task.startDate.minute,
                                                 task.endDate.hour, task.endDate.minute)


class TaskListTableWidget(QTableWidget):
    """
    重写QTableWidget
        第0列，任务名
        第1列，任务时间
        第2列，任务优先级
        第3列，任务花费时间
        第4列，任务空闲时间
        第5列，任务描述
    """

    def __init__(self, parent=None):
        super(TaskListTableWidget, self).__init__(parent)
        self.sortOrder = [Qt.SortOrder.AscendingOrder, Qt.SortOrder.DescendingOrder, Qt.SortOrder.DescendingOrder,
                          Qt.SortOrder.DescendingOrder, Qt.SortOrder.AscendingOrder]
        self.horizontalHeader().setSortIndicator(0, Qt.SortOrder.AscendingOrder)
        self.horizontalHeader().setSortIndicator(1, Qt.SortOrder.DescendingOrder)
        self.horizontalHeader().setSortIndicator(2, Qt.SortOrder.DescendingOrder)
        self.horizontalHeader().setSortIndicator(3, Qt.SortOrder.DescendingOrder)
        self.horizontalHeader().setSortIndicator(4, Qt.SortOrder.AscendingOrder)
        self.setSortingEnabled(True)

        self.horizontalHeader().sortIndicatorChanged.connect(self.handle_sort_indicator_changed)
        self.lastSortIndex = 0
        self.lastSortIndicatorOrder = Qt.SortOrder.AscendingOrder
        self.dateTasks = {}

    def handle_sort_indicator_changed(self, index, order):
        """
        避免根据任务描述进行排序
        :param index:
        :param order:
        :return:
        """
        if index == 5:
            self.horizontalHeader().setSortIndicator(self.lastSortIndex, self.lastSortIndicatorOrder)
        else:
            self.lastSortIndex = index
            self.lastSortIndicatorOrder = order

    def set_user(self, user: User):
        self.dateTasks.clear()
        for task in user.tasks.values():
            cur_date = task.startDate.date()
            end_date = task.endDate.date()
            while cur_date <= end_date:
                if cur_date not in self.dateTasks:
                    self.dateTasks[cur_date] = []
                self.dateTasks[cur_date].append(task)
                cur_date = cur_date + timedelta(days=1)
            if task.isRepeat:
                cur_date = task.startDate.date() + timedelta(days=1)
                continue_days = (task.endDate.date() - task.startDate.date()).days
                final_date = task.finalDate.date()
                while cur_date <= final_date:
                    if task.repeatDay[cur_date.weekday()]:
                        for i in range(continue_days + 1):
                            if cur_date + timedelta(days=i) not in self.dateTasks:
                                self.dateTasks[cur_date + timedelta(days=i)] = []
                            self.dateTasks[cur_date + timedelta(days=i)].append(task)
                        cur_date.weekday()
                    cur_date = cur_date + timedelta(days=1)

    def switch_date(self, new_date: date):
        self.clearContents()
        if new_date in self.dateTasks:
            for task in self.dateTasks[new_date]:
                self.add_task(task.name, format_task_mnd(task), str(task.importance), format_task_spend(task),
                              format_task_rest(task), task.description)

    def add_task(self, task_name, task_time, task_pri, task_spend, task_spare, task_description):
        """
        添加任务
        :param task_name: 任务名
        :param task_time: 任务时间，请严格按照xxxx-xx-xx--xxxx-xx-xx格式
        :param task_pri: 任务优先级
        :param task_spend: 任务时间花费，请严格按照xxd-xxh-xxm格式
        :param task_spare: 任务空闲时间，请严格按照xxd-xxh-xxm格式
        :param task_description: 任务描述
        :return:
        """
        self.setSortingEnabled(False)
        self.insertRow(0)
        name = QTableWidgetItem(task_name)
        name.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        time = QTableWidgetItem(task_time)
        time.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        pri = QTableWidgetItem(task_pri)
        pri.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        spend = QTableWidgetItem(task_spend)
        spend.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        spare = QTableWidgetItem(task_spare)
        spare.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        des = QTableWidgetItem(task_description)
        des.setTextAlignment(Qt.AlignHCenter | Qt.AlignVCenter)
        self.setItem(0, 0, name)
        self.setItem(0, 1, time)
        self.setItem(0, 2, pri)
        self.setItem(0, 3, spend)
        self.setItem(0, 4, spare)
        self.setItem(0, 5, des)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.setSortingEnabled(True)

    def re(self):
        """
        根据日期切换后调用此函数清空所有行（除表头）
        :return:
        """
        row_count = self.rowCount()
        for i in range(row_count):
            self.removeRow(0)
