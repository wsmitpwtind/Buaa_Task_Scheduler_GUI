from task import Task
from task import TaskState
from datetime import datetime
from task_todoList import TaskTodoList


# 任务清单的分析器，生成对应数据
class TaskTodoListAnalyzer:
    def __init__(self, user_id: str, start_todoList: TaskTodoList = None, end_todoList: TaskTodoList = None):
        self.user_id = user_id
        self.start_todoList: TaskTodoList = start_todoList
        self.end_todoList: TaskTodoList = end_todoList

    def add_start_todoList(self, start_todoList: TaskTodoList):
        self.start_todoList = start_todoList

    def add_end_todoList(self, end_todoList: TaskTodoList):
        self.end_todoList = end_todoList


