from PyQt5 import QtGui
from PyQt5.QtWidgets import QWidget, QApplication
from PyQt5 import QtCore
from PyQt5.QtCore import pyqtSignal, QObject, QPropertyAnimation, QEasingCurve, pyqtProperty, QPointF

from PyQt5.QtCore import Qt, QRectF
from PyQt5.QtGui import QPainterPath, QPainter, QColor
from point import get_dis, find_close, Dual, Point
from random import random


class BackgroundWidget(QWidget):
    def __init__(self, parent=None):
        super(BackgroundWidget, self).__init__(parent)

        self.setMouseTracking(True)
        self.points = []
        self.target = Dual(self.width() / 2, self.height() / 2)
        self.init_points()

        self.setMouseTracking(True)

        self.w = self.width()
        self.h = self.height()

    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter()
        painter.begin(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(), Qt.black)
        self.animate(painter)
        painter.end()

    def mouseMoveEvent(self, e: QtGui.QMouseEvent) -> None:
        super().mouseMoveEvent(e)
        self.target.x = e.x()
        self.target.y = e.y()
        self.update()

    def init_points(self):
        self.points.clear()
        # 创建点
        x_step = QApplication.desktop().width() / 20
        y_step = QApplication.desktop().height() / 20
        for x in range(0, QApplication.desktop().width(), int(x_step)):
            for y in range(0, QApplication.desktop().height(), int(y_step)):
                ox = x + random() * x_step
                oy = y + random() * y_step
                point = Point(ox, ox, oy, oy)
                point.valueChanged.connect(self.update)
                self.points.append(point)
        # 每个点寻找5个闭合点
        find_close(self.points)

    def animate(self, painter):
        for p in self.points:
            # 检测点的范围
            value = abs(get_dis(self.target, p))
            if value < 2000:
                p.lineColor.setAlphaF(0.3)
                p.circleColor.setAlphaF(0.6)
            elif value < 5000:
                p.lineColor.setAlphaF(0.1)
                p.circleColor.setAlphaF(0.3)
            elif value < 40000:
                p.lineColor.setAlphaF(0.02)
                p.circleColor.setAlphaF(0.1)
            else:
                p.lineColor.setAlphaF(0)
                p.circleColor.setAlphaF(0)
            # 画线条
            if p.lineColor.alpha():
                for pc in p.closest:
                    if not pc:
                        continue
                    path = QPainterPath()
                    path.moveTo(p.x, p.y)
                    path.lineTo(pc.x, pc.y)
                    painter.save()
                    painter.setPen(p.lineColor)
                    painter.drawPath(path)
                    painter.restore()
            # 画圆
            painter.save()
            painter.setPen(Qt.NoPen)
            painter.setBrush(p.circleColor)
            painter.drawRoundedRect(QRectF(
                p.x - p.radius, p.y - p.radius, 2 * p.radius, 2 * p.radius), p.radius, p.radius)
            painter.restore()
            # 开启动画
            p.init_animation()

