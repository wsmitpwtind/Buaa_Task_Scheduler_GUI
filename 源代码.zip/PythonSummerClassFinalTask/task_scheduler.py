import datetime

import task
from task import Task
from task import TaskState
from task_todoList import TaskTodoList


# 属性清单
# user_id           用户id

# all_tasks         全部任务
# notStarted_tasks  未开始任务
# process_tasks     进行中任务
# finish_tasks      完成任务
# outOfDate_tasks   过期任务
# recycle_tasks     回收站任务

# 调度原则
# 默认仅调度未开始任务
# 最高优先：完成全部任务
# 第二优先，Σ任务优先级*任务‘开始‘相对’最早开始‘时间差 最小

# 调度结果
# 不能完成全部任务：则得到完成任务重要性和最大者
# 能完成全部任务：返回两种结果，最早开始与最晚开始

def search_start(task: Task):
    return task.get_start_date()


def search_end(task: Task):
    return task.get_end_date()


class TaskScheduler:
    def __init__(self, user_id: str):
        self.user_id = user_id
        self.all_tasks: list[Task] = []
        self.notStarted_tasks: list[Task] = []
        self.process_tasks: list[Task] = []
        self.finish_tasks: list[Task] = []
        self.outOfDate_tasks: list[Task] = []
        self.recycle_tasks: list[Task] = []

    def add_task(self, task: Task, cur_date: datetime):
        for i in range(7):
            if task.repeatDay[i]:
                times = 0
                update_time = task.startDate
                while times < 4 and update_time < task.finishDate:
                    times += 1
                    new_start = task.startDate + datetime.timedelta(
                        days=(i - cur_date.weekday() + 7) % 7 + 7 * (times - 1))
                    new_end = task.endDate + datetime.timedelta(days=(i - cur_date.weekday() + 7) % 7 + 7 * (times - 1))
                    new_task = Task(task.task_id, task.name, task.description, task.kind, new_start, new_end,
                                    cur_date, task.spend, task.importance, task.isRepeat, task.repeatDay,
                                    task.finishDate, task.isLeisure, task.taskState, task.finishDate)
                    new_task.check_state(cur_date=cur_date)
                    self.add_task_ori(new_task, cur_date=cur_date)
        if not task.repeatDay[cur_date.weekday()]:
            self.add_task_ori(task, cur_date=cur_date)

    def add_task_ori(self, task: Task, cur_date: datetime):
        task.check_state(cur_date)
        self.all_tasks.append(task)
        if task.taskState == TaskState.NotStarted:
            self.notStarted_tasks.append(task)
        elif task.taskState == TaskState.Processing:
            self.process_tasks.append(task)
        elif task.taskState == TaskState.Finished:
            self.finish_tasks.append(task)
        elif task.taskState == TaskState.OutOfDate:
            self.outOfDate_tasks.append(task)
        elif task.taskState == TaskState.Recycled:
            self.recycle_tasks.append(task)

    def add_tasks(self, tasks: list[Task], cur_date: datetime):
        for i in tasks:
            self.add_task(i, cur_date)

    def del_task(self, task: Task):
        self.all_tasks.remove(task)
        if task.taskState == TaskState.NotStarted:
            self.notStarted_tasks.remove(task)
        elif task.taskState == TaskState.Processing:
            self.process_tasks.remove(task)
        elif task.taskState == TaskState.Finished:
            self.finish_tasks.remove(task)
        elif task.taskState == TaskState.OutOfDate:
            self.outOfDate_tasks.remove(task)
        elif task.taskState == TaskState.Recycled:
            self.recycle_tasks.remove(task)

    def check_tasks(self, cur_time: datetime):
        for task in self.all_tasks:
            if task.taskState == TaskState.NotStarted:
                self.notStarted_tasks.remove(task)
            elif task.taskState == TaskState.Processing:
                self.process_tasks.remove(task)
            elif task.taskState == TaskState.Finished:
                self.finish_tasks.remove(task)
            elif task.taskState == TaskState.OutOfDate:
                self.outOfDate_tasks.remove(task)
            elif task.taskState == TaskState.Recycled:
                self.recycle_tasks.remove(task)
            task.check_state(cur_time)
            if task.taskState == TaskState.NotStarted:
                self.notStarted_tasks.append(task)
            elif task.taskState == TaskState.Processing:
                self.process_tasks.append(task)
            elif task.taskState == TaskState.Finished:
                self.finish_tasks.append(task)
            elif task.taskState == TaskState.OutOfDate:
                self.outOfDate_tasks.append(task)
            elif task.taskState == TaskState.Recycled:
                self.recycle_tasks.append(task)

    def generate(self, searchType: str):
        taskList = self.notStarted_tasks.copy()
        if searchType == 'start':
            taskList.sort(key=search_start)
        elif searchType == 'end':
            taskList.sort(key=search_end, reverse=True)
        else:
            # print('Error!!!')
            pass
        if len(taskList) == 0:
            return False
        start_ans = self.branch_start(0, taskList[0].startDate, taskList, TaskTodoList())
        end_ans = self.branch_end(0, taskList[0].endDate, taskList, TaskTodoList())
        if end_ans:
            end_ans[2].time_table.reverse()
        if searchType == 'start':
            return start_ans
        elif searchType == 'end':
            return end_ans
        else:
            return False

    def branch_start(self, importance_delay: int, branch_time: datetime, taskList: list[Task], todoList: TaskTodoList):
        if len(taskList) == 0:
            return importance_delay, branch_time, todoList
        else:
            begin_task = taskList[0]
            best_ans = False
            updated_branch_time = max(begin_task.startDate, branch_time)
            for i in range(1, len(taskList)):
                if taskList[i].startDate < updated_branch_time + datetime.timedelta(
                        minutes=(begin_task.spend + begin_task.rest)) and taskList[i].endDate - datetime.timedelta(
                    minutes=taskList[i].spend + taskList[i].rest
                ) >= updated_branch_time:
                    taskListCopy = taskList.copy()
                    taskListCopy.remove(taskList[i])
                    todoListCopy = TaskTodoList(todoList.tasks.copy(), todoList.time_table.copy())
                    todoListCopy.add_task(taskList[i], max(updated_branch_time, taskList[i].startDate),
                                          max(updated_branch_time, taskList[i].startDate) + datetime.timedelta(
                                              minutes=taskList[i].spend + taskList[i].rest))
                    branch_ans = self.branch_start(
                        importance_delay + max(int((updated_branch_time - taskList[i].startDate).total_seconds()) // 60,
                                               0) *
                        taskList[i].importance,
                        max(updated_branch_time, taskList[i].startDate) + datetime.timedelta(
                            minutes=taskList[i].spend + taskList[i].rest),
                        taskListCopy, todoListCopy)
                    if branch_ans:
                        if best_ans == False:
                            best_ans = branch_ans
                        elif branch_ans[0] < best_ans[0]:
                            best_ans = branch_ans
                        elif branch_ans[0] == best_ans[0] and branch_ans[1] < best_ans[1]:
                            best_ans = branch_ans
            for i in range(1, len(taskList)):
                if taskList[i].endDate - datetime.timedelta(
                        minutes=taskList[i].spend + taskList[i].rest) < updated_branch_time + datetime.timedelta(minutes=begin_task.spend + begin_task.rest):
                    this_ans = False
                    return best_ans
            taskListCopy = taskList.copy()
            taskListCopy.remove(begin_task)
            todoListCopy = TaskTodoList(todoList.tasks.copy(), todoList.time_table.copy())
            todoListCopy.add_task(begin_task, updated_branch_time,
                                  updated_branch_time + datetime.timedelta(minutes=begin_task.spend + begin_task.rest))
            this_ans = self.branch_start(
                importance_delay + max(int((branch_time - begin_task.startDate).total_seconds()) // 60,
                                       0) *
                begin_task.importance,
                updated_branch_time + datetime.timedelta(minutes=begin_task.spend + begin_task.rest),
                taskListCopy, todoListCopy)
            if best_ans == False:
                return this_ans
            else:
                if not this_ans:
                    return best_ans
                elif best_ans[0] > this_ans[0]:
                    return this_ans
                elif best_ans[0] == this_ans[0] and best_ans[1] > this_ans[1]:
                    return this_ans
                else:
                    return best_ans

    def branch_end(self, importance_delay: int, branch_time: datetime, taskList: list[Task], todoList: TaskTodoList):
        if len(taskList) == 0:
            return importance_delay, branch_time, todoList
        else:
            begin_task = taskList[0]
            best_ans = False
            updated_branch_time = min(begin_task.endDate, branch_time)
            for i in range(1, len(taskList)):
                if taskList[i].endDate > updated_branch_time - datetime.timedelta(minutes=begin_task.spend + begin_task.rest) and \
                        taskList[i].startDate + datetime.timedelta(
                    minutes=taskList[i].spend + taskList[i].rest) <= updated_branch_time:
                    taskListCopy = taskList.copy()
                    taskListCopy.remove(taskList[i])
                    todoListCopy = TaskTodoList(todoList.tasks.copy(), todoList.time_table.copy())
                    todoListCopy.add_task(taskList[i],
                                          min(updated_branch_time, taskList[i].endDate) - datetime.timedelta(
                                              minutes=taskList[i].spend+ taskList[i].rest), min(updated_branch_time, taskList[i].endDate))
                    branch_ans = self.branch_start(
                        importance_delay + max(int((taskList[i].endDate - updated_branch_time).total_seconds()) // 60,
                                               0) *
                        taskList[i].importance,
                        min(updated_branch_time, taskList[i].endDate) - datetime.timedelta(
                            minutes=taskList[i].spend+ taskList[i].rest),
                        taskListCopy, todoListCopy)
                    if branch_ans:
                        if best_ans == False:
                            best_ans = branch_ans
                        elif branch_ans[0] < best_ans[0]:
                            best_ans = branch_ans
                        elif branch_ans[0] == best_ans[0] and branch_ans[1] < best_ans[1]:
                            best_ans = branch_ans
            for i in range(1, len(taskList)):
                if taskList[i].startDate + datetime.timedelta(
                        minutes=taskList[i].spend+ taskList[i].rest) > updated_branch_time - datetime.timedelta(minutes=begin_task.spend + begin_task.rest):
                    this_ans = False
                    return best_ans
            taskListCopy = taskList.copy()
            taskListCopy.remove(begin_task)
            todoListCopy = TaskTodoList(todoList.tasks.copy(), todoList.time_table.copy())
            todoListCopy.add_task(begin_task, updated_branch_time - datetime.timedelta(minutes=begin_task.spend + begin_task.rest),
                                  updated_branch_time
                                  )
            this_ans = self.branch_end(
                importance_delay + max(int((begin_task.endDate - branch_time).total_seconds()) // 60,
                                       0) *
                begin_task.importance,
                updated_branch_time - datetime.timedelta(minutes=begin_task.spend + begin_task.rest),
                taskListCopy, todoListCopy)
            if best_ans == False:
                return this_ans
            else:
                if not this_ans:
                    return best_ans
                elif best_ans[0] > this_ans[0]:
                    return this_ans
                elif best_ans[0] == this_ans[0] and best_ans[1] > this_ans[1]:
                    return this_ans
                else:
                    return best_ans


if __name__ == "__main__":
    taskScheduler = TaskScheduler('user1')
    task1 = task.Task('id1', 'name1', 'description1', task.TaskKind['Sport'],
                      start_date=datetime.datetime(2022, 8, 1, 12, 10),
                      end_date=datetime.datetime(2022, 8, 2, 23, 45),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=1440,
                      importance=3,
                      is_leisure=False
                      )
    task2 = task.Task('id2', 'name2', 'description2', task.TaskKind['Study'],
                      start_date=datetime.datetime(2022, 8, 1, 18, 00),
                      end_date=datetime.datetime(2022, 8, 1, 22, 30),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=60,
                      importance=2,
                      is_leisure=False
                      )
    task3 = task.Task('id3', 'name3', 'description3', task.TaskKind['Work'],
                      start_date=datetime.datetime(2022, 8, 1, 18, 00),
                      end_date=datetime.datetime(2022, 8, 1, 22, 30),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=60,
                      importance=4,
                      is_leisure=False
                      )
    task4 = task.Task('id4', 'name4', 'description4', task.TaskKind['Rest'],
                      start_date=datetime.datetime(2022, 8, 2, 18, 00),
                      end_date=datetime.datetime(2022, 8, 3, 22, 30),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=60,
                      importance=5,
                      is_leisure=False
                      )
    taskScheduler.add_tasks([task1, task2, task3, task4], cur_date=datetime.datetime(2022, 7, 1, 0, 00))
    # 解释:任务1优先级高于任务2，但是如果优先完成任务2则无法完成全部任务
    ans = taskScheduler.generate('start')
    # print(ans)
