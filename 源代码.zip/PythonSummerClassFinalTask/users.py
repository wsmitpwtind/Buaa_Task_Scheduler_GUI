from user import User
from user import load as load_user
import random
from xml.etree import ElementTree
import file_operation


class Users:
    """
    用于管理所有用户
    """
    able_user_id_list = [chr(x) for x in range(48, 58)] + \
                        [chr(x) for x in range(65, 91)] + \
                        [chr(x) for x in range(97, 123)]

    def __init__(self, data_file_name):
        self.users = {}
        self.ids = set()
        self.data_file_name = data_file_name
        file_operation.require(data_file_name)
        try:
            xml = ElementTree.parse(data_file_name)
        except ElementTree.ParseError:
            self.save()
            xml = ElementTree.parse(data_file_name)

        users_element = xml.getroot()
        for user_element in users_element:
            user_id = user_element.attrib['user_id']
            user = load_user(user_element)
            self.users[user_id] = user
            self.ids.add(user_id)

    def get_user(self, user_id: str, user_keyword: str) -> [int, User]:
        """
        获取保存用户的类
        :param user_id: 用户id
        :param user_keyword: 用户密码
        :return: 返回查询结果和用户类
            [0, <User>]: 查询成功
            [1, None]: 用户id不存在
            [2, None]: 用户id存在，但密码不符
        """
        if user_id not in self.ids:
            return 1, None
        user = self.users[user_id]
        if not user.check_keyword(user_keyword):
            return 2, None
        return 0, user

    def distribute_id(self):
        new_id = ""
        while True:
            for i in range(10):
                new_id += self.able_user_id_list[random.randint(0, len(self.able_user_id_list) - 1)]
            if new_id in self.ids:
                new_id = ""
            else:
                break
        self.ids.add(new_id)
        return new_id

    def add_user(self, user_name: str, user_keyword: str, user_check_keyword: str) -> User or None:
        """
        添加用户
        :param user_name: 用户名
        :param user_keyword: 用户密码
        :param user_check_keyword: 用户校验密码
        :return: 返回生成的用户
            <User> 生成成功
            None 生成失败
        """

        if user_keyword != user_check_keyword:
            return None
        user = User(self.distribute_id(), user_name, user_keyword)
        self.users[user.user_id] = user
        return user

    def delete_user(self, user_id: str, user_keyword: str) -> int:
        """
        注销账户
        :param user_id: 用户id
        :param user_keyword: 用户密码
        :return:
            0: 注销成功
            1: 用户id不存在
            2: 密码不符
        """
        if user_id not in self.ids:
            return 1
        user = self.users[user_id]
        if not user.check_keyword(user_keyword):
            return 2
        self.ids.remove(user_id)
        del self.users[user_id]
        return 0

    def save(self) -> None:
        users_element = ElementTree.Element("users")
        for user_id, user in self.users.items():
            user_element = ElementTree.SubElement(users_element, 'user_id', attrib={'user_id': user_id})
            user.save(user_element)
        et = ElementTree.ElementTree(users_element)
        et.write(self.data_file_name, encoding="utf-8")
