import os


def remove(path: str) -> None:
    """
    删除当前路径及当前路径下的所有文件
    :param path:
    :return:
    """
    if os.path.isdir(path):
        for file in os.listdir(path):
            remove(os.path.join(path, file))
        os.rmdir(path)
    else:
        os.remove(path)


def require(path: str) -> None:
    """
    要求目标文件必须存在，否则新建一个同名的空文件，可以递归创建目录，目标为目录时也将被删除
    :param path:
    :return:
    """
    if not os.path.exists(path):
        file_path, file_name = os.path.split(path)
        if file_path != '':
            os.makedirs(file_path, exist_ok=True)
        open(path, "w").close()
    else:
        if os.path.isdir(path):
            remove(path)
            open(path, "w").close()