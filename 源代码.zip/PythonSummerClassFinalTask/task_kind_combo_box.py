from PyQt5 import QtGui
from PyQt5.QtCore import pyqtSlot, pyqtSignal, QObject, QEvent, Qt
from PyQt5.QtGui import QMouseEvent
from PyQt5.QtWidgets import QComboBox, QWidget, QListWidget, QListWidgetItem
from task_kind_item_interface import Ui_Form


class TaskKindItemWidget(QWidget, Ui_Form):
    """
    本类为任务添加界面-任务类别选择-下拉菜单-项，实现项选择中同时可进行删除的功能
    """
    select: pyqtSignal = pyqtSignal(str)  # 选中信号，表明该项被选择，信号内容为任务类别。
    delete: pyqtSignal = pyqtSignal(str)  # 删除信号，表明该项被确定删除，信号内容为任务类别。

    def __init__(self, kind_name: str, parent=None):
        """
        构造函数
        :param kind_name: 任务类别名
        :param parent: 父容器
        """
        super(TaskKindItemWidget, self).__init__(parent)
        self.kindName = kind_name
        self.setupUi(self)
        self.KindNameLabel.setText(kind_name)
        self.DeleteButton.clicked.connect(self.send_delete_signal)
        if self.kindName == "默认":
            self.DeleteButton.setEnabled(False)

    def send_delete_signal(self):
        """
        发送删除信号
        :return:
        """
        if self.kindName != "默认":
            self.delete[str].emit(self.kindName)

    def mouseReleaseEvent(self, a0: QtGui.QMouseEvent) -> None:
        self.select[str].emit(self.kindName)


class TaskKindComboBox(QComboBox):
    """
    重写下拉菜单
    """
    def __init__(self, parent=None):
        super(TaskKindComboBox, self).__init__(parent)
        self.taskKindNameList = []
        self.listWidget = QListWidget()
        self.setModel(self.listWidget.model())
        self.setView(self.listWidget)
        self.add_kind("默认")

    def add_kind(self, kind_name: str) -> bool:
        """
        添加任务类别
        :param kind_name: 任务类别名，要求不能重名
        :return: 返回添加结果
        """
        if kind_name in self.taskKindNameList:
            return False
        item = TaskKindItemWidget(kind_name)
        item.select.connect(self.show_content)
        item.delete.connect(self.delete_item)
        self.taskKindNameList.append(kind_name)

        list_widget_item = QListWidgetItem(self.listWidget)
        self.listWidget.setItemWidget(list_widget_item, item)
        return True

    def re(self):
        self.listWidget.clear()
        self.taskKindNameList.clear()
        self.add_kind("默认")

    def add_kinds(self, kinds: list[str]):
        for kind in kinds:
            self.add_kind(kind)

    def get_kind(self):
        return self.taskKindNameList[self.currentIndex()]

    def get_kinds(self):
        return self.taskKindNameList

    def set_kind(self, kind:str):
        index = self.taskKindNameList.index(kind)
        self.setCurrentIndex(index)
        self.show_content(kind)

    def show_content(self, content:str) -> None:
        """
        显示选中项
        :param content: 任务类别名
        :return:
        """
        self.setEditText(content)
        self.hidePopup()

    def delete_item(self, content:str):
        """
        删除选中项
        :param content: 任务类别名
        :return:
        """
        index = self.taskKindNameList.index(content)
        self.listWidget.takeItem(index)
        del self.taskKindNameList[index]
        self.hidePopup()
        self.showPopup()




