import calendar
from datetime import timedelta
from datetime import datetime, date

from PyQt5 import QtGui
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import QWidget, QFrame
from day_frame import DayFrame
from task import Task
from task_todoList import TaskTodoList
from user import User


def format_datetime(date_time:datetime) -> datetime:
    return datetime(date_time.year, date_time.month, date_time.day, date_time.hour, date_time.minute, 0)


class DateWidget(QWidget):
    selectedChanged: pyqtSignal = pyqtSignal(date)
    selectedItemChanged: pyqtSignal = pyqtSignal([date, int])
    doubleItem: pyqtSignal = pyqtSignal([date, str])

    def __init__(self, days, parent=None):
        super(DateWidget, self).__init__(parent)
        self.frames: list[DayFrame] = [None for x in range(days)]
        self.lastSelected = -1
        self.selectDate: date = datetime.now().date()

        self.beginDate: date = None
        self.endDate: date = None

        # 计算日期对应的序号
        self.beginOrd = -1
        self.endOrd = -1
        self.curOrd = -1

        self.user: User = None
        self.taskToDoList: TaskTodoList = None
        self.dateTimeTask: dict = {}

    def create_map(self):
        """
        父子控件建立映射关系
        :return:
        """
        frames: list[DayFrame] = self.findChildren(DayFrame, options=Qt.FindDirectChildrenOnly)
        for frame in frames:
            index = int("".join(list(filter(str.isdigit, frame.objectName())))) - 1
            self.frames[index] = frame
            frame.create_map(index)
            frame.selected.connect(self.switch_selected)
            frame.selectedItemChange.connect(self.selected_item_change)
            frame.doubleItem.connect(self.double_selected)

        self.set_selected_date(self.selectDate)

    def set_todo_list(self, user:User, todo_list: TaskTodoList) -> None:
        self.user = user
        self.taskToDoList = todo_list
        self.dateTimeTask.clear()

        for task_id, task, begin_datetime, end_datetime in self.taskToDoList.time_table:
            end_date: date = end_datetime.date()
            cur_date = begin_datetime.date()
            while cur_date <= end_date:
                if cur_date not in self.dateTimeTask:
                    self.dateTimeTask[cur_date] = []
                self.dateTimeTask[cur_date].append([begin_datetime, end_datetime, self.user.tasks[task_id]])
                cur_date = cur_date + timedelta(days=1)
        self.update_show()

    def set_selected_date(self, selected_date: date):
        self.selectDate = selected_date
        if self.beginDate is None or self.endDate is None or \
                self.beginDate > self.selectDate or self.endDate < self.selectDate:
            self.get_date_range()
            self.update_show()
        self.switch_selected(self.curOrd)
        self.frames[self.curOrd].set_selected()

    def update_show(self):
        for i in range(len(self.frames)):
            if self.beginOrd <= i <= self.endOrd:
                cur_date: date = self.beginDate + timedelta(i - self.beginOrd)
                self.frames[i].set_date(cur_date)
                if cur_date in self.dateTimeTask:
                    for begin_datetime, end_datetime, task in self.dateTimeTask[cur_date]:
                        self.frames[i].add_task(begin_datetime, end_datetime, task)
                self.frames[i].setEnabled(True)
                self.frames[i].setVisible(True)
            else:
                self.frames[i].setVisible(False)
                self.frames[i].setEnabled(False)

    def get_date_range(self):
        pass

    def switch_selected(self, index: int, is_send: bool = True) -> None:
        """
        根据传入的索引值切换选中组件，index为负数时表示未选中任何组件
        :param index:
        :param is_send:
        :return:
        """
        if self.lastSelected >= 0:
            self.frames[self.lastSelected].set_not_selected()
        if index >= 0:
            self.lastSelected = index
            self.curOrd = index
            if is_send:
                self.selectedChanged[date].emit(self.beginDate + timedelta(days=self.curOrd-self.beginOrd))

    def mousePressEvent(self, e: QtGui.QMouseEvent) -> None:
        self.switch_selected(-1)
        e.accept()

    def get_selected_tasks(self):
        return self.frames[self.curOrd].get_tasks()

    def selected_item_change(self, index: int, task_id: str):
        self.switch_selected(index, False)
        self.selectedItemChanged[date, int].emit(self.beginDate + timedelta(days=self.curOrd-self.beginOrd),
                                                 task_id)

    def set_selected_item(self, current_row: int):
        self.frames[self.curOrd].set_selected_item_row(current_row)

    def double_selected(self, index: int, task_id: str):
        self.switch_selected(index, False)
        self.doubleItem[date, str].emit(self.beginDate + timedelta(days=self.curOrd-self.beginOrd),
                                        task_id)


class MonthDateWidget(DateWidget):
    def __init__(self, parent=None):
        super(MonthDateWidget, self).__init__(42, parent)

    def get_date_range(self):
        """
        获取本月的起始当前终止日期以及序号
        :return:
        """
        year = self.selectDate.year
        month = self.selectDate.month
        weekday, days = calendar.monthrange(year, month)
        # weekday 周一至周日对应0-6
        # 月份表格中, 周日为一周起始日
        # 每月的首日必定在第一排
        self.beginOrd = (weekday + 1) % 7
        # days 为当月天数
        self.endOrd = self.beginOrd + days - 1
        self.curOrd = self.selectDate.day + self.beginOrd - 1

        self.beginDate = date(year, month, 1)
        self.endDate = date(year, month, days)


class WeekDateWidget(DateWidget):
    def __init__(self, parent=None):
        super(WeekDateWidget, self).__init__(7, parent)

    def get_date_range(self):
        """
        获取本周的起始当前终止日期以及序号
        :return:
        """
        cur_weekday = self.selectDate.weekday()  # 当日为周几
        self.beginOrd = 0
        self.curOrd = (cur_weekday + 1) % 7
        self.endOrd = 6
        if self.curOrd != 0:

            self.beginDate = self.selectDate + timedelta(days=-self.curOrd)
        else:
            self.beginDate = self.selectDate
        if self.curOrd != 6:
            self.endDate = self.selectDate + timedelta(days=6-self.curOrd)
        else:
            self.endDate = self.selectDate


