import datetime

from PyQt5 import QtMultimedia
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QPixmap, QCursor
from PyQt5.QtMultimedia import QMediaContent
from PyQt5.QtWidgets import QApplication
from PyQt5 import QtCore

from memo_window import MemoWindow
import sys

import task
from task_scheduler import TaskScheduler


def ini():
    task1 = task.Task('id1', 'name1', 'description1', task.TaskKind['Sport'],
                      start_date=datetime.datetime(2022, 8, 1, 12, 10),
                      end_date=datetime.datetime(2022, 8, 2, 23, 45),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=1440,
                      importance=3,
                      is_leisure=False
                      )
    task2 = task.Task('id2', 'name2', 'description2', task.TaskKind['Rest'],
                      start_date=datetime.datetime(2022, 8, 1, 18, 00),
                      end_date=datetime.datetime(2022, 8, 1, 22, 30),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=60,
                      importance=2,
                      is_leisure=False
                      )
    task3 = task.Task('id3', 'name3', 'description3', task.TaskKind['Work'],
                      start_date=datetime.datetime(2022, 8, 1, 18, 00),
                      end_date=datetime.datetime(2022, 8, 1, 22, 30),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=60,
                      importance=4,
                      is_leisure=False
                      )
    task4 = task.Task('id4', 'name4', 'description4', task.TaskKind['Rest'],
                      start_date=datetime.datetime(2022, 8, 2, 18, 00),
                      end_date=datetime.datetime(2022, 8, 3, 22, 30),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=600,
                      importance=5,
                      is_leisure=False
                      )
    tasks = [task1, task2, task3, task4]
    return tasks


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MemoWindow()

    pixmap = QPixmap('cursor.png')
    cursor = QCursor(pixmap)
    window.setCursor(cursor)

    window.player.setVolume(30)
    window.player.play()

    window.show()
    sys.exit(app.exec_())
