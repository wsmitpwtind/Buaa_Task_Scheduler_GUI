from PyQt5.QtCore import QRegExp
from PyQt5.QtGui import QRegExpValidator
from PyQt5.QtWidgets import QLineEdit

IdLimit = "^[a-zA-Z0-9]+$"
NameLimit = "^[\u4e00-\u9fa5a-zA-Z0-9]+$"
KeywordLimit = "^[a-zA-Z0-9!#$%?]+$"


class UserIdLineEdit(QLineEdit):
    """
    重写QLineEdit，限制用户id框输入为大小写字母+数字
    """
    def __init__(self, parent=None):
        super(UserIdLineEdit, self).__init__(parent)
        reg = QRegExp(IdLimit)
        reg_val = QRegExpValidator(reg)
        self.setValidator(reg_val)


class UserNameEdit(QLineEdit):
    """
    重写QLineEdit，限制用户密码框输入为大小写字母+数字+部分特殊字符!#$%?
    """
    def __init__(self, parent=None):
        super(UserNameEdit, self).__init__(parent)
        reg = QRegExp(NameLimit)
        reg_val = QRegExpValidator(reg)
        self.setValidator(reg_val)


class UserKeywordLineEdit(QLineEdit):
    """
    重写QLineEdit，限制用户密码框输入为大小写字母+数字+部分特殊字符!#$%?
    """
    def __init__(self, parent=None):
        super(UserKeywordLineEdit, self).__init__(parent)
        reg = QRegExp(KeywordLimit)
        reg_val = QRegExpValidator(reg)
        self.setValidator(reg_val)