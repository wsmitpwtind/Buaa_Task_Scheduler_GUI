from datetime import datetime, date, timedelta
import calendar
import ctypes
from PyQt5 import QtChart, QtGui, QtMultimedia
from functools import partial

from PyQt5 import QtCore
from PyQt5.QtMultimedia import QMediaContent, QMediaPlayer

import task
from task import Task, TaskKindRe
from task_scheduler import TaskScheduler
from task_todoList import TaskTodoList
from ui_interface import Ui_MainWindow
from PyQt5.QtWidgets import QMainWindow, QMessageBox, QSizePolicy, QInputDialog, QLineEdit

from user import User
from users import Users

from random import randrange
from PyQt5.QtCore import Qt, QTimer, QSize, QDate, QModelIndex, QDateTime, QPointF, QUrl
from PyQt5.QtGui import QPainter


class MemoWindow(QMainWindow):
    def __init__(self):
        super(MemoWindow, self).__init__()
        path = 'music.mp3'
        self.has_input = False
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.player = QtMultimedia.QMediaPlayer()
        self.player.setMedia(QMediaContent(QUrl(path)))

        self.setWindowTitle("StarScheduler")
        self.setWindowIcon(QtGui.QIcon("./star.jpg"))
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("myappid")
        # 读取保存信息
        self.users = Users("data.xml")
        # 当前用户
        self.curUser: User = None
        self.taskSchedule = None
        self.selectDate = datetime.now().date()

        self.dayShowTaskList = []
        self.curTask: Task = None

        # 是否正在修改用户名
        self.isModifyingName = False

        # 设置标签特性
        # QtCore.Qt.FramelessWindowHint 无边框窗口
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        self.ui.statusbar.hide()

        # 窗口移动相关
        self.move_pos = QtCore.QPoint(0, 0)  # 用于记录窗口移动
        self.ui.TittleWidget.leftPressed.connect(self.title_pressed)
        self.ui.TittleWidget.leftPressedMove.connect(self.move_window)

        # 窗口关闭
        self.ui.CloseButton.clicked.connect(self.final)

        # 窗口最小化
        self.ui.MiminumButton.clicked.connect(self.showMinimized)

        # 窗口大小切换
        self.ui.NormalMaximumButton.clicked.connect(self.normal_maximum)

        # 登陆界面
        self.ui.LoginButton.clicked.connect(self.login)
        self.ui.RegisterButton.clicked.connect(self.turn_to_register)

        # 注册界面
        self.ui.RegisterAffirmButton.clicked.connect(self.register_affirm_register)
        self.ui.RegisterReturnButton.clicked.connect(self.register_return)

        # 用户名
        self.ui.RegisterUserNameInputLineEdit.inputRejected.connect(self.register_user_name_hint)
        self.ui.RegisterUserNameInputLineEdit.cursorPositionChanged.connect(self.register_clear_hint)
        self.ui.RegisterUserNameInputLineEdit.selectionChanged.connect(self.register_clear_hint)
        self.ui.RegisterUserNameInputLineEdit.textChanged.connect(self.register_clear_hint)
        self.ui.RegisterUserNameInputLineEdit.textChanged.connect(self.register_check_finish_all_input)
        self.ui.RegisterUserNameInputLineEdit.textEdited.connect(self.register_clear_hint)
        self.ui.RegisterUserNameInputLineEdit.returnPressed.connect(self.register_clear_hint)
        self.ui.RegisterUserNameInputLineEdit.returnPressed.connect(self.ui.RegisterUserNameInputLineEdit.clearFocus)

        # 密码
        self.ui.RegisterUserKeywordInputLineEdit.inputRejected.connect(self.register_user_keyword_hint)
        self.ui.RegisterUserKeywordInputLineEdit.cursorPositionChanged.connect(self.register_clear_hint)
        self.ui.RegisterUserKeywordInputLineEdit.selectionChanged.connect(self.register_clear_hint)
        self.ui.RegisterUserKeywordInputLineEdit.textChanged.connect(self.register_check_finish_all_input)
        self.ui.RegisterUserKeywordInputLineEdit.textChanged.connect(self.register_clear_hint)
        self.ui.RegisterUserKeywordInputLineEdit.textEdited.connect(self.register_clear_hint)
        self.ui.RegisterUserKeywordInputLineEdit.returnPressed.connect(self.register_clear_hint)
        self.ui.RegisterUserKeywordInputLineEdit.returnPressed.connect(
            self.ui.RegisterUserKeywordInputLineEdit.clearFocus)
        # 校验密码
        self.ui.RegisterUserCheckKeywordInputLineEdit.inputRejected.connect(self.register_user_check_keyword_hint)
        self.ui.RegisterUserCheckKeywordInputLineEdit.cursorPositionChanged.connect(self.register_clear_hint)
        self.ui.RegisterUserCheckKeywordInputLineEdit.selectionChanged.connect(self.register_clear_hint)
        self.ui.RegisterUserCheckKeywordInputLineEdit.textChanged.connect(self.register_check_finish_all_input)
        self.ui.RegisterUserCheckKeywordInputLineEdit.textChanged.connect(self.register_clear_hint)
        self.ui.RegisterUserCheckKeywordInputLineEdit.textEdited.connect(self.register_clear_hint)
        self.ui.RegisterUserCheckKeywordInputLineEdit.returnPressed.connect(self.register_clear_hint)
        self.ui.RegisterUserCheckKeywordInputLineEdit.returnPressed.connect(
            self.ui.RegisterUserCheckKeywordInputLineEdit.clearFocus)

        # 任务添加界面
        self.ui.TaskListTableWidget.add_task("1", "2", "3", "4", "5", "6")
        self.ui.TaskListTableWidget.add_task("2", "1", "30", "40", "50", "60")

        # 日历界面
        # 初始按月显示
        self.ui.DateShowWidget.setCurrentIndex(0)

        self.ui.DateEdit.setDate(self.selectDate)
        self.ui.DateEdit.dateChanged.connect(self.calendar_date_edit_change)

        self.ui.NextDateButton.clicked.connect(self.calendar_next_date)
        self.ui.LastDateButton.clicked.connect(self.calendar_last_date)
        self.ui.NextDateButton.clicked.connect(self.calendar_show_detail)
        self.ui.LastDateButton.clicked.connect(self.calendar_show_detail)

        self.ui.DateMonthWidget.create_map()
        self.ui.DateWeekWidget.create_map()
        self.ui.DateMonthWidget.selectedChanged.connect(self.calendar_date_widget_selected_changed)
        self.ui.DateWeekWidget.selectedChanged.connect(self.calendar_date_widget_selected_changed)
        self.ui.DateMonthWidget.selectedChanged.connect(self.calendar_show_detail)
        self.ui.DateWeekWidget.selectedChanged.connect(self.calendar_show_detail)

        self.ui.DayShowListWidget.currentRowChanged.connect(self.calendar_change_date_widget_row)
        self.ui.DateMonthWidget.selectedItemChanged.connect(self.calendar_change_list_widget_row)
        self.ui.DateWeekWidget.selectedItemChanged.connect(self.calendar_change_list_widget_row)

        self.ui.DayShowListWidget.doubleClicked.connect(self.calendar_day_widget_edit_task)
        self.ui.DateMonthWidget.doubleItem.connect(self.calendar_date_widget_edit_task)
        self.ui.DateWeekWidget.doubleItem.connect(self.calendar_date_widget_edit_task)

        self.ui.SwitchDateButton.clicked.connect(self.calendar_switch_view)

        self.ui.DateExtraAccountButton.clicked.connect(self.turn_to_account)
        self.ui.DateExtraTaskListButton.clicked.connect(self.turn_to_list)

        self.ui.DayAddButton.clicked.connect(self.calendar_add_task)
        self.ui.DayEditButton.clicked.connect(self.calendar_edit_task)

        self.ui.DateExtraAnalyzeButton.clicked.connect(self.turn_to_percentage)
        self.ui.pushButton.clicked.connect(self.creat_updown_map)
        self.ui.pushButton_2.clicked.connect(self.turn_to_percentage)
        self.ui.pushButton_3.clicked.connect(self.turn_to_nested)
        self.ui.pushButton_4.clicked.connect(self.creat_updown_map)
        self.ui.pushButton_5.clicked.connect(self.turn_to_percentage)
        self.ui.pushButton_6.clicked.connect(self.turn_to_nested)
        self.ui.pushButton_7.clicked.connect(self.turn_to_calendar)
        self.ui.pushButton_8.clicked.connect(self.turn_to_calendar)
        self.ui.pushButton_9.clicked.connect(self.turn_to_calendar)
        self.created_nested = False

        # 任务详情界面
        self.ui.TaskDetailFinishCheckBox.stateChanged.connect(self.detail_finish)
        self.ui.TaskDetailEditButton.clicked.connect(self.turn_to_task_add)
        self.ui.TaskDetailDeleteButton.clicked.connect(self.detail_delete)
        self.ui.TaskDetailReturnButton.clicked.connect(self.turn_to_calendar)

        # 任务添加界面
        self.ui.TaskAddReapeatComboBox.currentIndexChanged.connect(self.add_switch_is_repeat)
        self.ui.TaskAddKindAddButton.clicked.connect(self.add_add_kind)
        self.ui.TaskAddSaveButton.clicked.connect(self.add_save)
        self.ui.TaskAddReturnButton.clicked.connect(self.add_return)

        # 账户管理界面
        self.ui.AccountModifyNameButton.clicked.connect(self.account_modify_name)
        self.ui.AccountLogOutButton.clicked.connect(self.account_logout)
        self.ui.AccountModifyKeywordButton.clicked.connect(self.account_modify_keyword)
        self.ui.AccountReturnButton.clicked.connect(self.account_return)

        self.ui.AccountNameLineEdit.inputRejected.connect(self.account_user_name_hint)
        self.ui.AccountNameLineEdit.cursorPositionChanged.connect(self.account_clear_hint)
        self.ui.AccountNameLineEdit.selectionChanged.connect(self.account_clear_hint)
        self.ui.AccountNameLineEdit.textChanged.connect(self.account_clear_hint)
        self.ui.AccountNameLineEdit.textEdited.connect(self.account_clear_hint)
        self.ui.AccountNameLineEdit.returnPressed.connect(self.account_clear_hint)
        self.ui.AccountNameLineEdit.returnPressed.connect(self.account_finish_modify)

        # 密码修改页面
        self.ui.ModifyKeywordAffirmButton.clicked.connect(self.modify_affirm)
        self.ui.ModifyKeywordReturnButton.clicked.connect(self.modify_return)

        self.ui.ModifyKeywordUserOldKeywordInputLineEdit.cursorPositionChanged.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserOldKeywordInputLineEdit.selectionChanged.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserOldKeywordInputLineEdit.textChanged.connect(self.register_clear_hint)
        self.ui.ModifyKeywordUserOldKeywordInputLineEdit.textEdited.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserOldKeywordInputLineEdit.returnPressed.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserOldKeywordInputLineEdit.returnPressed.connect(
            self.ui.ModifyKeywordUserOldKeywordInputLineEdit.clearFocus)

        self.ui.ModifyKeywordUserKeywordInputLineEdit.inputRejected.connect(self.modify_user_keyword_hint)
        self.ui.ModifyKeywordUserKeywordInputLineEdit.cursorPositionChanged.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserKeywordInputLineEdit.selectionChanged.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserKeywordInputLineEdit.textChanged.connect(self.register_clear_hint)
        self.ui.ModifyKeywordUserKeywordInputLineEdit.textEdited.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserKeywordInputLineEdit.returnPressed.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserKeywordInputLineEdit.returnPressed.connect(
            self.ui.ModifyKeywordUserKeywordInputLineEdit.clearFocus)
        # 校验密码
        self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.inputRejected.connect(self.modify_user_check_keyword_hint)
        self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.cursorPositionChanged.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.selectionChanged.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.textChanged.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.textEdited.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.returnPressed.connect(self.modify_clear_hint)
        self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.returnPressed.connect(
            self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.clearFocus)

        # 任务列表界面
        self.ui.TaskListDateEdit.dateChanged.connect(self.list_switch_date)
        self.ui.TaskListReturnButton.clicked.connect(self.turn_to_calendar)

        self.turn_to_login()

    def detail_finish(self, *args):
        self.ui.TaskDetailFinishCheckBox.setEnabled(False)
        self.curTask.taskState = task.TaskState.Finished

    def detail_delete(self):
        reply = QMessageBox.question(self, " ", "确认删除吗！", QMessageBox.Yes | QMessageBox.Cancel,
                                     QMessageBox.Cancel)
        if reply == 16384:
            self.curUser.delete_task(self.curTask)
            self.curTask = 0
            self.turn_to_calendar()

    def add_add_kind(self):
        kind_name, ok = QInputDialog.getText(self, "新建任务类别", "请输入任务类别名", QLineEdit.Normal)
        if ok:
            if self.ui.TaskAddKindComboBox.add_kind(kind_name):
                self.ui.TaskAddKindComboBox.set_kind(kind_name)
                reply = QMessageBox.about(self, '添加成功', "添加成功")
            else:
                reply = QMessageBox.about(self, '添加失败', "当前任务类别已存在")

    def add_switch_is_repeat(self, *args):
        if self.ui.TaskAddReapeatComboBox.currentIndex() == 1:
            self.ui.TaskAddUserDefinedRepeatWidget.setVisible(True)
            self.ui.TaskAddUserDefinedRepeatWidget.setEnabled(True)
            self.ui.TaskAddPlanWidget.setVisible(True)
            self.ui.TaskAddPlanWidget.setEnabled(True)
        else:
            self.ui.TaskAddUserDefinedRepeatWidget.setVisible(False)
            self.ui.TaskAddUserDefinedRepeatWidget.setEnabled(False)
            self.ui.TaskAddPlanWidget.setVisible(False)
            self.ui.TaskAddPlanWidget.setEnabled(False)

    def add_save(self):
        def q_date_to_date(q_date: QDate):
            return date(q_date.year(), q_date.month(), q_date.day())

        def q_datetime_to_datetime(q_datetime: QDateTime):
            return datetime(q_datetime.date().year(), q_datetime.date().month(),
                            q_datetime.date().day(), q_datetime.time().hour(),
                            q_datetime.time().minute())

        task_name = self.ui.TaskAddNameLineEdit.text()
        if task_name == "":
            reply = QMessageBox.about(self, '保存失败', '任务名不能为空:')
            return
        task_kind = self.ui.TaskAddKindComboBox.get_kind()
        task_importance = self.ui.TaskAddPriSpinBox.value()
        task_begin_datetime = q_datetime_to_datetime(self.ui.TaskAddTimeDateBeginTimeEdit.dateTime())
        task_end_datetime = q_datetime_to_datetime(self.ui.TaskAddTimeDateEndTimeEdit.dateTime())
        if task_begin_datetime >= task_end_datetime:
            reply = QMessageBox.about(self, '保存失败', '任务开始时间必须小于结束时间:')
            return
        task_spend = self.ui.TaskAddSpendTimeSpinBox1.value() * 60 + self.ui.TaskAddSpendTimeSpinBox2.value()
        if task_spend == 0:
            reply = QMessageBox.about(self, '保存失败', '花费时间不能为0')
            return
        if (task_end_datetime - task_begin_datetime).seconds / 60 < task_spend:
            reply = QMessageBox.about(self, '保存失败', '花费时间不能超过起止时间差')
            return
        task_rest = self.ui.TaskAddRestTimeSpinBox1.value() * 60 + self.ui.TaskAddRestTimeSpinBox2.value()
        if self.ui.TaskAddReapeatComboBox.currentIndex() == 0:
            task_is_repeat = False
            task_repeat_day = [False for x in range(7)]
            task_final_date = self.selectDate
        else:
            task_is_repeat = True
            task_repeat_day = []
            task_repeat_day.append(self.ui.TaskAddUserDefinedRepeatCheckBox2.isChecked())
            task_repeat_day.append(self.ui.TaskAddUserDefinedRepeatCheckBox3.isChecked())
            task_repeat_day.append(self.ui.TaskAddUserDefinedRepeatCheckBox4.isChecked())
            task_repeat_day.append(self.ui.TaskAddUserDefinedRepeatCheckBox5.isChecked())
            task_repeat_day.append(self.ui.TaskAddUserDefinedRepeatCheckBox6.isChecked())
            task_repeat_day.append(self.ui.TaskAddUserDefinedRepeatCheckBox7.isChecked())
            task_repeat_day.append(self.ui.TaskAddUserDefinedRepeatCheckBox1.isChecked())
            task_final_date = q_date_to_date(self.ui.TaskAddPlanEndDateEdit.date())
            if task_begin_datetime.date() >= task_final_date:
                reply = QMessageBox.about(self, '保存失败', '重复截止时间必须晚于任务开始时间')
                return
            if (task_begin_datetime.date() - task_final_date).days > 28:
                reply = QMessageBox.about(self, '保存失败', '重复截止时间大于4周')
                return
        task_description = self.ui.TaskAddDescriptionBrowser.toPlainText()
        if self.curTask is None:
            task = Task(self.curUser.distribute_id(), task_name, task_description, task_kind, task_begin_datetime,
                        task_end_datetime, datetime.now(), task_spend, task_importance, task_rest,
                        task_is_repeat, task_repeat_day,
                        datetime(task_final_date.year, task_final_date.month, task_final_date.day, 23, 59), False)
        else:
            self.curUser.delete_task(self.curTask)
            task = Task(self.curTask.task_id, task_name, task_description, task_kind, task_begin_datetime,
                        task_end_datetime, datetime.now(), task_spend, task_importance, task_rest,
                        task_is_repeat, task_repeat_day,
                        datetime(task_final_date.year, task_final_date.month, task_final_date.day, 23, 59), False)
        self.curUser.add_task(task)
        reply = QMessageBox.about(self, '保存成功', '保存成功')
        self.turn_to_task_detail(task)

    def list_switch_date(self, q_date: QDate):
        self.ui.TaskListTableWidget.switch_date(date(q_date.year(), q_date.month(), q_date.day()))

    def add_return(self):
        if self.curTask is None:
            self.turn_to_calendar()
        else:
            self.turn_to_task_detail()

    def title_pressed(self, pos: QtCore.QPoint) -> None:
        """
        点击标题栏触发事件，记录移动值
        :param pos: 传入初始位置
        :return:
        """
        self.move_pos = pos - self.pos()

    def move_window(self, pos: QtCore.QPoint) -> None:
        """
        移动窗口
        :param pos: 鼠标移动中的位置
        :return:
        """
        self.move(pos - self.move_pos)

    def normal_maximum(self) -> None:
        """
        窗口恢复正常与最大化切换
        :return:
        """
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def login(self) -> None:
        id = self.ui.UserIdLineEdit.text()
        keyword = self.ui.KeywordLineEdit.text()
        result, user = self.users.get_user(id, keyword)
        if result == 0:
            self.curUser: User = user
            self.ui.TaskAddKindComboBox.re()
            for task in self.curUser.tasks.values():
                self.ui.TaskAddKindComboBox.add_kind(task.kind)
            self.turn_to_calendar()
        else:
            if result == 1:
                reply = QMessageBox.warning(self, '警告', '用户id不存在', QMessageBox.Yes)
                self.turn_to_login()
            else:
                reply = QMessageBox.warning(self, '警告', '密码不正确', QMessageBox.Yes)
                self.turn_to_login(id)

    def turn_to_login(self, default_id: str = "") -> None:
        """
        转到登陆界面
        :return:
        """
        self.ui.UserIdLineEdit.clear()
        self.ui.UserIdLineEdit.setText(default_id)
        self.ui.KeywordLineEdit.clear()
        self.ui.contentWidget.setCurrentIndex(0)

    def turn_to_percentage(self) -> None:
        if self.curUser != None:
            self.create_percentage_bar_chart(list(self.curUser.tasks.values()))

    def turn_to_nested(self) -> None:
        if self.curUser != None:
            if not self.created_nested:
                self.created_nested = True
                self.create_nested_donuts(list(self.curUser.tasks.values()))
            else:
                self.ui.contentWidget.setCurrentIndex(8)

    def turn_to_register(self) -> None:
        """
        转到注册界面
        :return:
        """
        self.ui.RegisterUserNameInputLineEdit.clear(),
        self.ui.RegisterUserKeywordInputLineEdit.clear(),
        self.ui.RegisterUserCheckKeywordInputLineEdit.clear()
        self.register_check_has_input()
        self.register_check_finish_all_input()
        self.ui.contentWidget.setCurrentIndex(1)

    def turn_to_calendar(self) -> None:
        """
        转到日历界面
        :return:
        """
        self.taskSchedule = self.curUser.task_schedule()
        if self.taskSchedule == 1:
            self.ui.DateMonthWidget.set_todo_list(self.curUser, TaskTodoList())
            self.ui.DateWeekWidget.set_todo_list(self.curUser, TaskTodoList())
        elif not self.taskSchedule[0]:
            self.ui.DateMonthWidget.set_todo_list(self.curUser, TaskTodoList())
            self.ui.DateWeekWidget.set_todo_list(self.curUser, TaskTodoList())
            reply = QMessageBox.about(self, '警告', '调度失败')
        else:
            self.ui.DateMonthWidget.set_todo_list(self.curUser, self.taskSchedule[0][2])
            self.ui.DateWeekWidget.set_todo_list(self.curUser, self.taskSchedule[0][2])

        self.ui.contentWidget.setCurrentIndex(2)
        self.calendar_turn_to_month()
        self.calendar_show_detail()

    def turn_to_account(self) -> None:
        """
        转到账户管理界面
        :return:
        """
        self.ui.contentWidget.setCurrentIndex(6)
        self.ui.AccountIdShowLabel.setText(self.curUser.user_id)
        self.ui.AccountNameLineEdit.setText(self.curUser.user_name)
        self.ui.AccountNameLineEdit.setFocusPolicy(Qt.NoFocus)
        self.ui.AccountNameLineEdit.clearFocus()
        self.ui.AccountModifyNameButton.setText("编辑")
        self.account_clear_hint()

    def turn_to_task_add(self, is_new: bool = False):
        """
        转向任务添加界面
        :return:
        """
        if is_new:
            self.curTask = None
            self.ui.TaskAddNameLineEdit.setText("")
            self.ui.TaskAddKindComboBox.setCurrentIndex(0)
            self.ui.TaskAddPriSpinBox.setValue(0)
            self.ui.TaskAddTimeDateBeginTimeEdit.setDate(self.selectDate)
            self.ui.TaskAddTimeDateEndTimeEdit.setDate(self.selectDate)
            self.ui.TaskAddSpendTimeSpinBox1.setValue(0)
            self.ui.TaskAddSpendTimeSpinBox2.setValue(0)
            self.ui.TaskAddRestTimeSpinBox1.setValue(0)
            self.ui.TaskAddRestTimeSpinBox2.setValue(0)
            self.ui.TaskAddReapeatComboBox.setCurrentIndex(0)
            self.ui.TaskAddUserDefinedRepeatWidget.setVisible(False)
            self.ui.TaskAddUserDefinedRepeatWidget.setEnabled(False)
            self.ui.TaskAddPlanWidget.setVisible(False)
            self.ui.TaskAddPlanWidget.setEnabled(False)
            self.ui.TaskAddUserDefinedRepeatCheckBox1.setChecked(False)
            self.ui.TaskAddUserDefinedRepeatCheckBox2.setChecked(False)
            self.ui.TaskAddUserDefinedRepeatCheckBox3.setChecked(False)
            self.ui.TaskAddUserDefinedRepeatCheckBox4.setChecked(False)
            self.ui.TaskAddUserDefinedRepeatCheckBox5.setChecked(False)
            self.ui.TaskAddUserDefinedRepeatCheckBox6.setChecked(False)
            self.ui.TaskAddUserDefinedRepeatCheckBox7.setChecked(False)
            self.ui.TaskAddDescriptionBrowser.setText("")
        else:
            self.ui.TaskAddNameLineEdit.setText(self.curTask.name)
            self.ui.TaskAddKindComboBox.set_kind(self.curTask.kind)
            self.ui.TaskAddPriSpinBox.setValue(self.curTask.importance)
            self.ui.TaskAddTimeDateBeginTimeEdit.setDateTime(self.curTask.startDate)
            self.ui.TaskAddTimeDateEndTimeEdit.setDateTime(self.curTask.endDate)
            self.ui.TaskAddSpendTimeSpinBox1.setValue(self.curTask.spend // 60)
            self.ui.TaskAddSpendTimeSpinBox2.setValue(self.curTask.spend % 60)
            self.ui.TaskAddRestTimeSpinBox1.setValue(self.curTask.rest // 60)
            self.ui.TaskAddRestTimeSpinBox2.setValue(self.curTask.rest % 60)
            if self.curTask.isRepeat:
                self.ui.TaskAddReapeatComboBox.setCurrentIndex(1)
                self.ui.TaskAddUserDefinedRepeatWidget.setVisible(True)
                self.ui.TaskAddUserDefinedRepeatWidget.setEnabled(True)
                self.ui.TaskAddUserDefinedRepeatCheckBox2.setChecked(self.curTask.repeatDay[0])
                self.ui.TaskAddUserDefinedRepeatCheckBox3.setChecked(self.curTask.repeatDay[1])
                self.ui.TaskAddUserDefinedRepeatCheckBox4.setChecked(self.curTask.repeatDay[2])
                self.ui.TaskAddUserDefinedRepeatCheckBox5.setChecked(self.curTask.repeatDay[3])
                self.ui.TaskAddUserDefinedRepeatCheckBox6.setChecked(self.curTask.repeatDay[4])
                self.ui.TaskAddUserDefinedRepeatCheckBox7.setChecked(self.curTask.repeatDay[5])
                self.ui.TaskAddUserDefinedRepeatCheckBox1.setChecked(self.curTask.repeatDay[6])
                self.ui.TaskAddPlanWidget.setVisible(True)
                self.ui.TaskAddPlanWidget.setEnabled(True)
                self.ui.TaskAddPlanEndDateEdit.setDate(self.curTask.finalDate)
            else:
                self.ui.TaskAddReapeatComboBox.setCurrentIndex(0)
                self.ui.TaskAddUserDefinedRepeatWidget.setVisible(False)
                self.ui.TaskAddUserDefinedRepeatWidget.setEnabled(False)
                self.ui.TaskAddPlanWidget.setVisible(False)
                self.ui.TaskAddPlanWidget.setEnabled(False)
                self.ui.TaskAddUserDefinedRepeatCheckBox1.setChecked(False)
                self.ui.TaskAddUserDefinedRepeatCheckBox2.setChecked(False)
                self.ui.TaskAddUserDefinedRepeatCheckBox3.setChecked(False)
                self.ui.TaskAddUserDefinedRepeatCheckBox4.setChecked(False)
                self.ui.TaskAddUserDefinedRepeatCheckBox5.setChecked(False)
                self.ui.TaskAddUserDefinedRepeatCheckBox6.setChecked(False)
                self.ui.TaskAddUserDefinedRepeatCheckBox7.setChecked(False)
                self.ui.TaskAddPlanEndDateEdit.setDate(self.selectDate)
            self.ui.TaskAddDescriptionBrowser.setText(self.curTask.description)
        self.ui.contentWidget.setCurrentIndex(4)

    def turn_to_task_detail(self, _task: Task = None):
        """
        转向任务详情界面
        :param _task:
        :return:
        """
        if _task is not None:
            self.curTask = _task
        self.ui.TaskDetailNameShowLabel.setText(self.curTask.name)
        self.ui.TaskDetailKindShowLabel.setText(self.curTask.kind)
        self.ui.TaskDetailPriShowLabel.setText(str(self.curTask.importance))
        self.ui.TaskDetailStateShowLabel.setText(self.curTask.taskState.trans())
        self.ui.TaskDetailTimeShowLabel.setText(task.format_datetime_str(self.curTask.startDate) + "-" +
                                                task.format_datetime_str(self.curTask.endDate))
        self.ui.TaskDetailRestTimeShowLabel.setText(task.format_spend_str(self.curTask.rest))
        self.ui.TaskDetailDescriptionTextBrowser.setText(self.curTask.description)
        self.ui.TaskDetailDescriptionTextBrowser.setEnabled(False)
        self.ui.TaskDetailSpendTimeShowLabel.setText(task.format_spend_str(self.curTask.spend))
        if self.curTask.isRepeat:
            self.ui.TaskDetailRepeatShowLabel.setText("重复")
            self.ui.TaskDetailUserDefinedRepeatWidget.setVisible(True)
            self.ui.TaskDetailUserDefinedRepeatWidget.setEnabled(True)
            self.ui.TaskDetailUserDefinedRepeatCheckBox2.setChecked(self.curTask.repeatDay[0])
            self.ui.TaskDetailUserDefinedRepeatCheckBox3.setChecked(self.curTask.repeatDay[1])
            self.ui.TaskDetailUserDefinedRepeatCheckBox4.setChecked(self.curTask.repeatDay[2])
            self.ui.TaskDetailUserDefinedRepeatCheckBox5.setChecked(self.curTask.repeatDay[3])
            self.ui.TaskDetailUserDefinedRepeatCheckBox6.setChecked(self.curTask.repeatDay[4])
            self.ui.TaskDetailUserDefinedRepeatCheckBox7.setChecked(self.curTask.repeatDay[5])
            self.ui.TaskDetailUserDefinedRepeatCheckBox1.setChecked(self.curTask.repeatDay[6])
            self.ui.TaskDetailUserDefinedRepeatCheckBox1.setEnabled(False)
            self.ui.TaskDetailUserDefinedRepeatCheckBox2.setEnabled(False)
            self.ui.TaskDetailUserDefinedRepeatCheckBox3.setEnabled(False)
            self.ui.TaskDetailUserDefinedRepeatCheckBox4.setEnabled(False)
            self.ui.TaskDetailUserDefinedRepeatCheckBox5.setEnabled(False)
            self.ui.TaskDetailUserDefinedRepeatCheckBox6.setEnabled(False)
            self.ui.TaskDetailUserDefinedRepeatCheckBox7.setEnabled(False)
            self.ui.TaskDetailPlanShowLabel.setText(task.format_datetime_str(self.curTask.finishDate))
        else:
            self.ui.TaskDetailRepeatShowLabel.setText("不重复")
            self.ui.TaskDetailUserDefinedRepeatWidget.setVisible(False)
            self.ui.TaskDetailUserDefinedRepeatWidget.setEnabled(False)
            self.ui.TaskDetailPlanShowLabel.setText("无")
        if self.curTask.taskState == task.TaskState.NotStarted or self.curTask.taskState == task.TaskState.Processing:
            self.ui.TaskDetailFinishCheckBox.setChecked(False)
            self.ui.TaskDetailFinishCheckBox.setEnabled(True)
        else:
            if self.curTask.taskState == task.TaskState.Finished:
                self.ui.TaskDetailFinishCheckBox.setChecked(True)
            else:
                self.ui.TaskDetailFinishCheckBox.setChecked(False)
            self.ui.TaskDetailFinishCheckBox.setEnabled(False)
        self.ui.contentWidget.setCurrentIndex(3)

    def turn_to_list(self) -> None:
        self.ui.TaskListDateEdit.setDate(self.selectDate)
        self.ui.TaskListTableWidget.set_user(self.curUser)
        self.ui.TaskListTableWidget.switch_date(self.selectDate)
        self.ui.contentWidget.setCurrentIndex(5)

    def turn_to_modify(self) -> None:
        """
        转到密码修改界面
        :return:
        """
        self.ui.contentWidget.setCurrentIndex(7)
        self.modify_clear_hint()

    def register_check_has_input(self) -> None:
        """
        检查是否已经存在有输入
        :return:
        """
        self.has_input = (len(self.ui.RegisterUserNameInputLineEdit.text()) > 0 or
                          len(self.ui.RegisterUserKeywordInputLineEdit.text()) > 0 or
                          len(self.ui.RegisterUserCheckKeywordInputLineEdit.text()) > 0)

    def register_clear_hint(self, *args) -> None:
        """
        清空提示
        :param args: 收集参数
        :return:
        """
        self.ui.RegisterUserNameHintLabel.setVisible(False)
        self.ui.RegisterUserNameHintLabel.setEnabled(False)
        self.ui.RegisterUserNameHintLabel.clear()
        self.ui.RegisterUserKeywordHintLabel.setVisible(False)
        self.ui.RegisterUserKeywordHintLabel.setEnabled(False)
        self.ui.RegisterUserKeywordHintLabel.clear()
        self.ui.RegisterUserCheckKeywordHintLabel.setVisible(False)
        self.ui.RegisterUserCheckKeywordHintLabel.setEnabled(False)
        self.ui.RegisterUserCheckKeywordHintLabel.clear()

    def register_user_name_hint(self) -> None:
        """
        用户名输入不符合规则时弹出提示
        :return:
        """
        self.ui.RegisterUserNameHintLabel.setVisible(True)
        self.ui.RegisterUserNameHintLabel.setEnabled(True)
        self.ui.RegisterUserNameHintLabel.setText("用户名只能为中文、字母或数字")

    def register_user_keyword_hint(self) -> None:
        """
        密码输入不符合规则时弹出提示
        :return:
        """
        self.ui.RegisterUserKeywordHintLabel.setVisible(True)
        self.ui.RegisterUserKeywordHintLabel.setEnabled(True)
        self.ui.RegisterUserKeywordHintLabel.setText("密码只能为字母、数字以及!、#、$、%、?")

    def register_user_check_keyword_hint(self) -> None:
        """
        检验密码输入不符合规则时弹出提示
        :return:
        """
        self.ui.RegisterUserCheckKeywordHintLabel.setVisible(True)
        self.ui.RegisterUserCheckKeywordHintLabel.setEnabled(True)
        self.ui.RegisterUserCheckKeywordHintLabel.setText("密码只能为字母、数字以及!、#、$、%、?")

    def register_finish_input(self) -> None:
        """
        完成输入后判断是否有输入，并清楚提示
        :return:
        """
        self.register_check_has_input()
        self.ui.RegisterUserNameHintLabel.setText("")
        self.ui.RegisterUserKeywordHintLabel.setText("")
        self.ui.RegisterUserCheckKeywordHintLabel.setText("")

    def register_check_finish_all_input(self, *args) -> None:
        """
        检验是否均完成了输入
        :return:
        """
        self.ui.RegisterAffirmButton.setEnabled(len(self.ui.RegisterUserNameInputLineEdit.text()) > 0 and
                                                len(self.ui.RegisterUserKeywordInputLineEdit.text()) > 0 and
                                                len(self.ui.RegisterUserCheckKeywordInputLineEdit.text()) > 0)

    def register_affirm_register(self) -> None:
        """
        启动注册校验
        :return:
        """
        user = self.users.add_user(self.ui.RegisterUserNameInputLineEdit.text(),
                                   self.ui.RegisterUserKeywordInputLineEdit.text(),
                                   self.ui.RegisterUserCheckKeywordInputLineEdit.text())
        if user is not None:
            reply = QMessageBox.about(self, '注册成功', '您的id为:' + user.user_id)
            self.turn_to_login(user.user_id)
        else:
            reply = QMessageBox.warning(self, '警告', '前后两次输入的密码不同', QMessageBox.Yes)
            self.ui.RegisterUserKeywordInputLineEdit.clear()
            self.ui.RegisterUserCheckKeywordInputLineEdit.clear()

    def register_return(self) -> None:
        """
        返回登录界面
        :return:
        """
        self.register_check_has_input()
        if self.has_input:
            reply = QMessageBox.question(self, " ", "确认退出吗？您有修改尚未保存！", QMessageBox.Yes | QMessageBox.Cancel,
                                         QMessageBox.Cancel)
            if reply == 16384:
                self.turn_to_login()
        else:
            self.turn_to_login()

    def calendar_date_edit_change(self, q_date: QDate):
        self.selectDate = date(q_date.year(), q_date.month(), q_date.day())
        if self.ui.DateShowWidget.currentIndex() == 0:
            self.ui.DateMonthWidget.set_selected_date(self.selectDate)
        else:
            self.ui.DateWeekWidget.set_selected_date(self.selectDate)

    def calendar_next_date(self):
        if self.ui.DateShowWidget.currentIndex() == 0:
            year = self.selectDate.year
            month = self.selectDate.month + 1
            if month > 12:
                year = year + 1
                month = 1
            day = self.selectDate.day
            if day > calendar.monthrange(year, month)[1]:
                day = calendar.monthrange(year, month)[1]
            self.selectDate = date(year, month, day)
            self.ui.DateMonthWidget.set_selected_date(self.selectDate)
        else:
            self.selectDate = self.selectDate + timedelta(days=7)
            self.ui.DateWeekWidget.set_selected_date(self.selectDate)
        self.ui.DateEdit.setDate(self.selectDate)

    def calendar_last_date(self):
        if self.ui.DateShowWidget.currentIndex() == 0:
            year = self.selectDate.year
            month = self.selectDate.month - 1
            if month < 1:
                year = year - 1
                month = 12
            day = self.selectDate.day
            if day > calendar.monthrange(year, month)[1]:
                day = calendar.monthrange(year, month)[1]
            self.selectDate = date(year, month, day)
            self.ui.DateMonthWidget.set_selected_date(self.selectDate)
        else:
            self.selectDate = self.selectDate - timedelta(days=7)
            self.ui.DateWeekWidget.set_selected_date(self.selectDate)
        self.ui.DateEdit.setDate(self.selectDate)

    def calendar_date_widget_selected_changed(self, _date: date):
        self.selectDate = _date
        self.ui.DateEdit.setDate(_date)

    def calendar_switch_view(self):
        if self.ui.DateShowWidget.currentIndex() == 0:
            self.calendar_turn_to_week()
        else:
            self.calendar_turn_to_month()

    def calendar_turn_to_month(self):
        self.ui.DateShowWidget.setCurrentIndex(0)
        self.ui.DateMonthWidget.set_selected_date(self.selectDate)

    def calendar_turn_to_week(self):
        self.ui.DateShowWidget.setCurrentIndex(1)
        self.ui.DateWeekWidget.set_selected_date(self.selectDate)

    def calendar_show_detail(self, *args):
        if self.ui.DateShowWidget.currentIndex() == 0:
            self.dayShowTaskList = self.ui.DateMonthWidget.get_selected_tasks()
        else:
            self.dayShowTaskList = self.ui.DateWeekWidget.get_selected_tasks()
        self.ui.DayShowLabel.setText(str(self.selectDate.month) + "." + str(self.selectDate.day))
        self.ui.DayShowListWidget.clear()
        for begin_datetime, end_datetime, task in self.dayShowTaskList:
            self.ui.DayShowListWidget.addItem(
                ("{:02d}:{:02d}-{:02d}:{:02d}: {}".format(begin_datetime.hour, begin_datetime.minute,
                                                          end_datetime.hour, end_datetime.minute,
                                                          task.name)))

    def calendar_change_list_widget_row(self, current_date: date, current_row: int):
        self.calendar_date_widget_selected_changed(current_date)
        self.ui.DayShowListWidget.setCurrentRow(current_row)

    def calendar_change_date_widget_row(self, current_row: int):
        if self.ui.DateShowWidget.currentIndex() == 0:
            self.ui.DateMonthWidget.set_selected_item(current_row)
        else:
            self.ui.DateWeekWidget.set_selected_item(current_row)

    def calendar_date_widget_edit_task(self, current_date: date, task_id: str):
        self.calendar_date_widget_selected_changed(current_date)
        self.turn_to_task_detail(self.curUser.tasks[task_id])

    def calendar_day_widget_edit_task(self, current_row: QModelIndex):
        self.turn_to_task_detail(self.dayShowTaskList[current_row.row()][2])

    def calendar_edit_task(self):
        if len(self.dayShowTaskList) <= 0:
            return
        if self.ui.DayShowListWidget.currentRow() >= 0:
            self.turn_to_task_detail(self.dayShowTaskList[self.ui.DayShowListWidget.currentRow()][2])
        else:
            self.turn_to_task_detail(self.dayShowTaskList[0][2])

    def calendar_add_task(self):
        self.turn_to_task_add(True)

    def account_modify_name(self):
        if self.isModifyingName:
            self.account_finish_modify()
        else:
            self.account_begin_modify()

    def account_begin_modify(self):
        self.ui.AccountNameLineEdit.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.ui.AccountNameLineEdit.setFocus()
        self.ui.AccountModifyNameButton.setText("完成编辑")
        self.isModifyingName = True

    def account_finish_modify(self):
        if self.curUser.set_name(self.ui.AccountNameLineEdit.text()) == 0:
            reply = QMessageBox.about(self, '修改成功', "您的用户名已被修改")
            self.ui.AccountNameLineEdit.clearFocus()
            self.ui.AccountNameLineEdit.setFocusPolicy(QtCore.Qt.NoFocus)
            self.ui.AccountModifyNameButton.setText("编辑")
            self.isModifyingName = False
            self.turn_to_account()
        else:
            reply = QMessageBox.warning(self, '警告', '新用户名与原用户名相同', QMessageBox.Yes)

    def account_logout(self):
        keyword, ok = QInputDialog.getText(self, "确认注销", "确认注销吗，请输入密码:", QLineEdit.Password)
        if ok:
            if self.users.delete_user(self.curUser.user_id, keyword) == 0:
                self.curUser = None
                reply = QMessageBox.about(self, '注销成功', "账户已被注销")
                self.turn_to_login()
            else:
                reply = QMessageBox.about(self, '注销失败', "密码错误")

    def account_modify_keyword(self):
        if self.isModifyingName:
            reply = QMessageBox.question(self, " ", "确认退出吗？您有修改尚未保存！", QMessageBox.Yes | QMessageBox.Cancel,
                                         QMessageBox.Cancel)
            if reply == 16384:
                self.turn_to_modify()
            else:
                self.account_clear_hint()
        else:
            self.turn_to_modify()

    def account_return(self):
        if self.isModifyingName:
            reply = QMessageBox.question(self, " ", "确认退出吗？您有修改尚未保存！", QMessageBox.Yes | QMessageBox.Cancel,
                                         QMessageBox.Cancel)
            if reply == 16384:
                self.turn_to_calendar()
            else:
                self.account_clear_hint()
        else:
            self.turn_to_modify()

    def account_clear_hint(self, *args) -> None:
        """
        清空提示
        :param args: 收集参数
        :return:
        """
        self.ui.AccountUserNameHintLabel.setVisible(False)
        self.ui.AccountUserNameHintLabel.setEnabled(False)
        self.ui.AccountUserNameHintLabel.clear()

    def account_user_name_hint(self) -> None:
        """
        用户名输入不符合规则时弹出提示
        :return:
        """
        self.ui.AccountUserNameHintLabel.setVisible(True)
        self.ui.AccountUserNameHintLabel.setEnabled(True)
        self.ui.AccountUserNameHintLabel.setText("用户名只能为中文、字母或数字")

    def modify_affirm(self) -> None:
        result = self.curUser.set_keyword(self.ui.ModifyKeywordUserOldKeywordInputLineEdit.text(),
                                          self.ui.ModifyKeywordUserKeywordInputLineEdit.text(),
                                          self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.text())
        if result == 0:
            reply = QMessageBox.about(self, '修改成功', "您的密码已被修改，请重新登陆")
            id = self.curUser.user_id
            self.curUser = None
            self.turn_to_login(id)
        elif result == 1:
            reply = QMessageBox.about(self, '错误', "原密码错误")
            self.ui.ModifyKeywordUserOldKeywordInputLineEdit.clear()
            self.modify_clear_hint()
        elif result == 2:
            reply = QMessageBox.about(self, '错误', "两次输入密码不同")
            self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.clear()
            self.modify_clear_hint()
        elif result == 3:
            reply = QMessageBox.about(self, '错误', "新密码与原密码相同")
            self.ui.ModifyKeywordUserKeywordInputLineEdit.clear()
            self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.clear()
            self.modify_clear_hint()

    def modify_return(self) -> None:
        if self.ui.ModifyKeywordUserOldKeywordInputLineEdit.text() != "" or \
                self.ui.ModifyKeywordUserKeywordInputLineEdit.text() != "" or \
                self.ui.ModifyKeywordUserCheckKeywordInputLineEdit.text() != "":
            reply = QMessageBox.question(self, " ", "确认退出吗？您有修改尚未保存！", QMessageBox.Yes | QMessageBox.Cancel,
                                         QMessageBox.Cancel)
            if reply == 16384:
                self.turn_to_account()
            else:
                self.modify_clear_hint()
        else:
            self.turn_to_account()

    def modify_clear_hint(self, *arg) -> None:

        """
        清空提示
        :param args: 收集参数
        :return:
        """
        self.ui.ModifyKeywordUserKeywordHintLabel.setVisible(False)
        self.ui.ModifyKeywordUserKeywordHintLabel.setEnabled(False)
        self.ui.ModifyKeywordUserKeywordHintLabel.clear()
        self.ui.ModifyKeywordUserCheckKeywordHintLabel.setVisible(False)
        self.ui.ModifyKeywordUserCheckKeywordHintLabel.setEnabled(False)
        self.ui.ModifyKeywordUserCheckKeywordHintLabel.clear()

    def modify_user_keyword_hint(self) -> None:
        """
        密码输入不符合规则时弹出提示
        :return:
        """
        self.ui.ModifyKeywordUserKeywordHintLabel.setVisible(True)
        self.ui.ModifyKeywordUserKeywordHintLabel.setEnabled(True)
        self.ui.ModifyKeywordUserKeywordHintLabel.setText("密码只能为字母、数字以及!、#、$、%、?")

    def modify_user_check_keyword_hint(self) -> None:
        """
        检验密码输入不符合规则时弹出提示
        :return:
        """
        self.ui.ModifyKeywordUserCheckKeywordHintLabel.setVisible(True)
        self.ui.ModifyKeywordUserCheckKeywordHintLabel.setEnabled(True)
        self.ui.ModifyKeywordUserCheckKeywordHintLabel.setText("密码只能为字母、数字以及!、#、$、%、?")

    def final(self):
        reply = QMessageBox.question(self, "窗口关闭确认", "确认关闭窗口？", QMessageBox.Yes | QMessageBox.Cancel,
                                     QMessageBox.Cancel)
        if reply == 16384:
            self.users.save()
            self.close()

    def create_nested_donuts(self, taskList: list[Task]):
        self.ui.contentWidget.setCurrentIndex(8)
        self.donuts = []

        chart = QtChart.QChart()
        self.chart_view = QtChart.QChartView(chart)
        chart.legend().setVisible(False)
        chart.setTitle("各类型历史任务分布饼图")
        chart.setAnimationOptions(QtChart.QChart.AllAnimations)

        self.chart_view.chart().setTheme(QtChart.QChart.ChartThemeDark)
        # self.chart_view.setMinimumSize(QSize(100, 100))

        self.min_size = 0.1
        self.max_size = 0.9

        temp = self.ui.TaskAddKindComboBox.taskKindNameList
        extra_kind = []
        for i in range(0, len(temp)):
            times = 0
            for j in taskList:
                if j.kind == temp[i]:
                    times += 1
            if times != 0:
                extra_kind.append([temp[i], times])

        donut_count = min((len(extra_kind) - 1) // 3 + 1, 3)
        now = 0

        if True:
            for i in range(donut_count):
                donut = QtChart.QPieSeries()
                slcCount = min(len(extra_kind) - now, 3)
                if len(extra_kind) - now == 4:
                    slcCount = 2

                for j in range(slcCount):
                    now += 1
                    value = extra_kind[now - 1][1]
                    slc = QtChart.QPieSlice(extra_kind[now - 1][0] + ' ' + str(value), value)
                    slc.setLabelVisible(True)
                    slc.setLabelColor(Qt.white)
                    slc.setLabelPosition(QtChart.QPieSlice.LabelInsideTangential)

                    # Connection using an extra parameter for the slot
                    if len(taskList) != 1:
                        slc.hovered[bool].connect(partial(self.explode_slice, slc=slc))

                    donut.append(slc)
                    size = (self.max_size - self.min_size) / donut_count
                    donut.setHoleSize(self.min_size + i * size)
                    donut.setPieSize(self.min_size + (i + 1) * size)

                self.donuts.append(donut)
                self.chart_view.chart().addSeries(donut)

        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self.update_rotation)
        self.update_timer.start(2000)
        self.ui.gridLayout_3.addWidget(self.chart_view)

    def update_rotation(self):
        for donut in self.donuts:
            phase_shift = randrange(-50, 100)
            donut.setPieStartAngle(donut.pieStartAngle() + phase_shift)
            donut.setPieEndAngle(donut.pieEndAngle() + phase_shift)

    def explode_slice(self, exploded, slc):
        if exploded:
            self.update_timer.stop()
            slice_startangle = slc.startAngle()
            slice_endangle = slc.startAngle() + slc.angleSpan()

            donut = slc.series()
            idx = self.donuts.index(donut)
            for i in range(idx + 1, len(self.donuts)):
                self.donuts[i].setPieStartAngle(slice_endangle)
                self.donuts[i].setPieEndAngle(360 + slice_startangle)
        else:
            for donut in self.donuts:
                donut.setPieStartAngle(0)
                donut.setPieEndAngle(360)

            self.update_timer.start()

        slc.setExploded(exploded)

    def create_percentage_bar_chart(self, taskList: list[Task]):
        self.ui.contentWidget.setCurrentIndex(9)
        temp = self.ui.TaskAddKindComboBox.taskKindNameList
        extra_kind = []
        for i in range(0, len(temp)):
            times = [0, 0, 0, 0, 0, 0, 0]
            for j in taskList:
                if j.kind == temp[i]:
                    times[j.finishDate.weekday()] += 1
            if times != 0:
                extra_kind.append([temp[i], times])

        extra_sets = []
        for i in extra_kind:
            this_set = QtChart.QBarSet(i[0])
            this_set.append(i[1])
            extra_sets.append(this_set)

        series = QtChart.QPercentBarSeries()

        for i in extra_sets:
            series.append(i)

        chart = QtChart.QChart()
        chart.addSeries(series)
        chart.setTitle("周际任务类型分布图")
        chart.setAnimationOptions(QtChart.QChart.SeriesAnimations)

        categories = ["Mon", "Tue", "Wed", "Thur", "Fri", "Sat", "Sun"]
        axis = QtChart.QBarCategoryAxis()
        axis.append(categories)
        chart.createDefaultAxes()
        chart.setAxisX(axis, series)

        chart.legend().setVisible(True)
        chart.legend().setAlignment(Qt.AlignBottom)

        self.ui.chart_view = QtChart.QChartView(chart)
        self.ui.chart_view.setRenderHint(QPainter.Antialiasing)
        self.ui.chart_view.chart().setTheme(QtChart.QChart.ChartThemeDark)

        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.ui.chart_view.sizePolicy().hasHeightForWidth())
        self.ui.chart_view.setSizePolicy(sizePolicy)
        self.ui.chart_view.setMinimumSize(QSize(0, 300))
        self.ui.gridLayout_4.addWidget(self.ui.chart_view, 0, 0, 9, 9)


    def creat_updown_map(self):
        ans = self.taskSchedule
        self.ui.contentWidget.setCurrentIndex(10)
        self.series = QtChart.QLineSeries()
        #self.series.append(0, 6)
        #self.series.append(2, 4)
        #self.series.append(3, 8)
        #self.series.append(7, 4)
        #self.series.append(10, 5)
        if self.taskSchedule[0]:
            todo_list = self.taskSchedule[0][2]
            pla = 0
            for i in todo_list.time_table:
                pla += 1
                self.series.append(QPointF(pla, (i[2] - i[1].startDate).seconds / 3600))

        self.chart = QtChart.QChart()
        self.chart.legend().hide()
        self.chart.addSeries(self.series)
        self.chart.createDefaultAxes()
        self.chart.setTitle("各任务延迟时间折线图")

        self.chartView = QtChart.QChartView(self.chart)
        self.chartView.setRenderHint(QPainter.Antialiasing)

        self.chart.setAnimationOptions(QtChart.QChart.AllAnimations)

        self.chartView.chart().setTheme(QtChart.QChart.ChartThemeDark)

        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.chartView.sizePolicy().hasHeightForWidth())
        self.chartView.setSizePolicy(sizePolicy)
        self.ui.gridLayout_5.addWidget(self.chartView, 0, 0, 9, 9)