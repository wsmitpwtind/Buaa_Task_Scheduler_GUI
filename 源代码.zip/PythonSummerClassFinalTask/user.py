import datetime
import random
from xml.etree import ElementTree

import task
import task_scheduler
from task import Task
from task import load as task_load
from task_scheduler import TaskScheduler


class User:
    """
    用于保存单个用户的信息
    """
    able_task_id_list = [chr(x) for x in range(48, 58)] + \
                        [chr(x) for x in range(65, 91)] + \
                        [chr(x) for x in range(97, 123)]

    def __init__(self, user_id: str, user_name: str, user_keyword: str):
        """
        构造函数
        :param user_id: 用户id
        :param user_name: 用户名
        :param user_keyword: 密码
        """
        self.user_id = user_id
        self.user_name = user_name
        self.user_keyword = user_keyword
        self.tasks = {}
        self.taskKinds = []

        self.task_scheduler = TaskScheduler(user_id=self.user_id)

    def set_name(self, new_name: str) -> int:
        """
        修改昵称
        :param new_name: 新昵称
        :return: 返回修改结果
            0: 修改成功
            1: 修改失败
        """
        if self.user_name == new_name:
            return 1
        self.user_name = new_name
        return 0

    def set_keyword(self, old_keyword: str, new_keyword: str, check_keyword: str) -> int:
        """
        修改密码
        :param old_keyword: 原密码
        :param new_keyword: 新密码
        :param check_keyword: 再次输入新密码
        :return: 返回修改结果
            0: 成功修改
            1: 原密码不符
            2: 两次输入新密码不符
            3: 原密码与新密码相同
        """
        if self.user_keyword != old_keyword:
            return 1
        if new_keyword != check_keyword:
            return 2
        if self.user_keyword == new_keyword:
            return 3
        self.user_keyword = new_keyword
        return 0

    def check_keyword(self, keyword: str) -> bool:
        """
        查询密码是否正确
        :param keyword: 待校验密码
        :return: 检验是否成功
        """
        return self.user_keyword == keyword

    def add_task(self, task: Task):
        if task.task_id in self.tasks:
            return False
        else:
            self.tasks[task.task_id] = task
            return True

    def save(self, parent_element: ElementTree.Element) -> None:
        user_element = ElementTree.SubElement(parent_element, "user_account",
                                              attrib={"user_name": self.user_name, "user_keyword": self.user_keyword})
        for task_id, task in self.tasks.items():
            task_element = ElementTree.SubElement(user_element, 'task_id', attrib={'task_id': task_id})
            task.save(task_element)

    def delete_task(self, task: Task):
        del self.tasks[task.task_id]

    def task_schedule(self):
        self.task_scheduler = TaskScheduler(user_id=self.user_id)
        self.task_scheduler.add_tasks(list(self.tasks.values()), datetime.datetime.now())
        if len(self.tasks) == 0:
            return 1
        start_ans = self.task_scheduler.generate('start')
        end_ans = self.task_scheduler.generate('end')
        return start_ans, end_ans

    def distribute_id(self):
        new_id = ""
        while True:
            for i in range(10):
                new_id += self.able_task_id_list[random.randint(0, len(self.able_task_id_list) - 1)]
            if new_id in self.tasks:
                new_id = ""
            else:
                break
        return new_id


def load(parent_element: ElementTree.Element) -> User:
    user_id = parent_element.attrib['user_id']

    # for account_element in parent_element:
    user_element = parent_element[0]
    account_dict = user_element.attrib
    user_name = account_dict['user_name']
    user_keyword = account_dict['user_keyword']

    user = User(user_id, user_name, user_keyword)
    for task_element in user_element:
        task = task_load(task_element)
        user.add_task(task)
    return user


if __name__ == "__main__":
    user = User('id1', 'name1', 'keyword1')

    task1 = task.Task('id1', 'name1', 'description1', task.TaskKind['Sport'],
                      start_date=datetime.datetime(2022, 8, 1, 12, 10),
                      end_date=datetime.datetime(2022, 8, 2, 23, 45),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=1440,
                      importance=3,
                      is_leisure=False
                      )
    task2 = task.Task('id2', 'name2', 'description2', task.TaskKind['Study'],
                      start_date=datetime.datetime(2022, 8, 1, 18, 00),
                      end_date=datetime.datetime(2022, 8, 1, 22, 30),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=60,
                      importance=2,
                      is_leisure=False
                      )
    task3 = task.Task('id3', 'name3', 'description3', task.TaskKind['Work'],
                      start_date=datetime.datetime(2022, 8, 1, 18, 00),
                      end_date=datetime.datetime(2022, 8, 1, 22, 30),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=60,
                      importance=4,
                      is_leisure=False
                      )
    task4 = task.Task('id4', 'name4', 'description4', task.TaskKind['Rest'],
                      start_date=datetime.datetime(2022, 8, 2, 18, 00),
                      end_date=datetime.datetime(2022, 8, 3, 22, 30),
                      cur_date=datetime.datetime(2022, 7, 1, 0, 00),
                      spend=60,
                      importance=5,
                      is_leisure=False
                      )
    user.add_task(task1)
    user.add_task(task2)
    user.add_task(task3)
    user.add_task(task4)

    ans = user.task_schedule()
    # print(ans[0])
    # print(ans[0][2].time_table)
