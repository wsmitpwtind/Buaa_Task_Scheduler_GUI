from PyQt5 import QtGui
from PyQt5.QtGui import QPainter
from PyQt5.QtWidgets import QWidget, QStyleOption, QStyle
from PyQt5 import QtCore
from PyQt5.QtCore import pyqtSignal


class TittleWidget(QWidget):
    """
    重写标题栏窗口，添加自定义信号
    """
    leftPressed: pyqtSignal = pyqtSignal(QtCore.QPoint)  # 左键点击信号
    leftPressedMove: pyqtSignal = pyqtSignal(QtCore.QPoint)  # 左键点击中移动信号

    def __init__(self, parent):
        super(QWidget, self).__init__(parent)
        self.isLeftPressed = False  # 是否按下了左键

    def mousePressEvent(self, e:QtGui.QMouseEvent) -> None:
        super(TittleWidget, self).mousePressEvent(e)
        if e.button() == QtCore.Qt.LeftButton:
            self.leftPressed[QtCore.QPoint].emit(e.globalPos())
            self.isLeftPressed = True

    def mouseMoveEvent(self, e: QtGui.QMouseEvent) -> None:
        super(TittleWidget, self).mouseMoveEvent(e)
        if self.isLeftPressed:
            self.leftPressedMove[QtCore.QPoint].emit(e.globalPos())

    def mouseReleaseEvent(self, e: QtGui.QMouseEvent) -> None:
        super(TittleWidget, self).mouseReleaseEvent(e)
        self.isLeftPressed = False

    def paintEvent(self, e: QtGui.QPaintEvent) -> None:
        styleOption = QStyleOption()
        styleOption.initFrom(self)
        painter = QPainter(self)
        self.style().drawPrimitive(QStyle.PE_Widget, styleOption, painter, self)